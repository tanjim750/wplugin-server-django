jQuery(document).ready(function ($) {
    $('.zyncops-send-to-courier').on('click', function (e) {
        e.preventDefault(); // 👈 Prevent page refresh

        const orderId = $(this).data('order-id');

        if (!confirm('Are you sure you want to send this order to courier?')) {
            return;
        }

        $.post(ZyncOpsAjax.ajax_url, {
            action: 'send_order_to_courier',
            nonce: ZyncOpsAjax.nonce,
            order_id: orderId
        }, function (response) {
            if (response.success) {
                alert(`✅ ${response.data.message}\n📦 Tracking ID: ${response.data.tracking_id}`);
                location.reload(); // Optional: reload to update tracking info
            } else {
                alert(` Failed to send order: ${JSON.stringify(response.data)}`);
            }
        });
    });

    $('.zyncops-track-parcel').on('click', function (e) {
        e.preventDefault(); // 👈 Prevent page refresh

        const orderId = $(this).data('order-id');

        $.post(ZyncOpsAjax.ajax_url, {
            action: 'track_parcel',
            nonce: ZyncOpsAjax.track,
            order_id: orderId
        }, function (response) {
            if (response.success) {
                const body = response.data;
            
                if (body.tracking) {
                    const tracking = body.tracking;
                    if (tracking.length > 0) {
                        alert(tracking[tracking.length - 1].desc);
                    } else {
                        alert("No tracking data found.");
                    }
                } else if (body.message) {
                    alert(body.message);
                } else {
                    alert("No data found to display.");
                }
            } else {
                alert(response.data ? response.data:`Something went wrong. Please try again.`);
            }
        });
    });

    $('.zyncops-courier-ratio').each(function() {
        const order = $(this).data('order');
        const api_url = $(this).data('url');
        
        const body = $(this);
    
        if(order){
            const orderId = order.id;
            const license_key = order.key;
            const phone = order.billing.phone;
            const domain = window.location.hostname;

            let savedData = localStorage.getItem('zyncOpsCourierRatio#'+orderId);
            savedData = savedData ? JSON.parse(savedData): null;
            let savedDate = savedData && savedData.date ? new Date(savedData.date):new Date();
            const now = new Date();
            // Get difference in milliseconds
            const diffMs = now - savedDate;
            // Convert to days
            const diffDays = diffMs / (1000 * 60 * 60 * 24);

            let total = 0;
            let total_success = 0;
            let total_cancel = 0;
            let cancel_ratio = 0;

            if(savedData && savedData.date && diffDays < 2){
                
                total = savedData.total;
                total_success = savedData.total_success;
                total_cancel = savedData.total_cancel;
                cancel_ratio = savedData.cancel_ratio;
                
                body.html(`
                <div class="ratio-bar" style="display: flex; overflow: hidden;">
                     <div class="bg-green" style="width: ${100 - cancel_ratio}%; height: 100%;"></div>
                     <div class="bg-red" style="width: ${cancel_ratio}%; height: 100%;"></div>
                </div>
                 <div><span>Total:</span>${total}</div>
                 <div><span class="text-green">Success:</span>${total_success}</div>
                 <div><span class="text-red">Cancelled:</span>${total_cancel}</div>
            `)
            }else{
                fetch(api_url,{
                    method:'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body:JSON.stringify(
                        {
                            license_key,
                            domain,
                            phone,
                            order: order
                        }
                    )
                })
                .then(response => {
                    if (!response.ok) {
                        // throw new Error('Network response was not ok: ' + response.statusText);
                        body.html(`
                            <button onClick="window.reload()">Reload</button>
                        `)
                    }
                    return response.json(); // or response.text() if it's not JSON
                })
                .then(data => {
                    // console.log('Success:', data);
                    Object.values(data).forEach(e => {
                        total += Number(e.total) || 0;
                        total_success += e.success;
                        total_cancel += e.cancel;
                    });

                    let cancel_ratio = (total > 0) ? (total_cancel / total) * 100 : 0;

                    if(total && total != 0){
                        localStorage.setItem('zyncOpsCourierRatio#'+orderId, JSON.stringify({
                            total,
                            total_success,
                            total_cancel,
                            cancel_ratio,
                            date: new Date()
                        }));
                    }
                
                    body.html(`
                        <div class="ratio-bar" style="display: flex; overflow: hidden;">
                            <div class="bg-green" style="width: ${100 - cancel_ratio}%; height: 100%;"></div>
                            <div class="bg-red" style="width: ${cancel_ratio}%; height: 100%;"></div>
                        </div>
                        <div><span>Total:</span>${total}</div>
                        <div><span class="text-green">Success:</span>${total_success}</div>
                        <div><span class="text-red">Cancelled:</span>${total_cancel}</div>
                    `)

                })
                .catch(error => {
                    console.error('Error:', error);
                    body.html(`
                        <button onClick="window.reload()">Reload</button>
                    `)
                });
            }
        }
    });
});
