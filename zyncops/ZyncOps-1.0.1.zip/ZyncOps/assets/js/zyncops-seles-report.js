jQuery(document).ready(function ($) {
    $('.filter-custom-report').on('click', function (e) {
        e.preventDefault();

        const from_date = $('.report-from-date').val();
        const to_date = $('.report-to-date').val();

        $.post(ZyncOpsReportAjax.ajax_url, {
            action: 'zyncops_custom_report',
            nonce: ZyncOpsReportAjax.custom_report,
            from_date: from_date,
            to_date: to_date
        }, function (response) {
            if (response.success) {
                const data = response.data;
                $('.custom-total-sales-order').text(data.total_orders);
                $('.custom-total-sales-earning').html(data.total_earnings);
                $('.custom-total-sales-refunded').html(data.total_refunded);
                $('.custom-total-sales-profit').html(data.gross_profit);
            } else {
                alert(response.data); // Error message from wp_send_json_error
            }
        }).fail(function () {
            alert('⚠️ Something went wrong. Please try again later.');
        });
    });
});
