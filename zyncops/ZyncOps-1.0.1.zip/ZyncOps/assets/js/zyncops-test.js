console.log("✅ zyncops-test.js loaded");

jQuery(document).ready(function ($) {
    console.log("✅ DOM ready, sending AJAX request...");

    $.post(zyncops_data.ajax_url, {
        action: 'zyncops_test_request'
    }, function (response) {
        console.log("✅ AJAX Response:", response);
    });
});
