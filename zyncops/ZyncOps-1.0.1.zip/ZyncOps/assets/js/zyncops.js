jQuery(document).ready(function ($) {
    $('.send-to-zyncops').on('click', function () {
        const button = $(this);
        const orderId = button.data('order-id');

        button.prop('disabled', true).text('Sending...');

        $.ajax({
            url: zyncops_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'zyncops_send_order',
                nonce: zyncops_ajax.nonce,
                order_id: orderId
            },
            success: function (response) {
                if (response.success) {
                    alert(response.data.message);
                } else {
                    alert('Failed: ' + response.data);
                }
            },
            error: function () {
                alert('AJAX failed.');
            },
            complete: function () {
                button.prop('disabled', false).text('Send to Zyncops');
            }
        });
    });
});
