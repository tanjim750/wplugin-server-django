jQuery(document).ready(function ($) {
    $('.zyncops-distribution-user').on('change', function (e) {
        e.preventDefault();

        const select = $(this);
        const selectedUserId = select.val();
        const saveButton = select.siblings('.zyncops-distribution-save');

        if (selectedUserId) {
            saveButton.prop('disabled', false);
        } else {
            saveButton.prop('disabled', true);
        }
    });

    $('.zyncops-distribution-save').on('click', function (e) {
        e.preventDefault();

        const $button = $(this);
        const orderId = $button.data('order-id');
        const $select = $button.siblings('.zyncops-distribution-user');
        const userId = $select.val();

        // Optional: disable the button during AJAX
        $button.prop('disabled', true).text('Saving...');

        $.post(ZyncOpsDistAjax.ajax_url, {
            action: 'save_order_distibution', // ✅ Correct AJAX action
            security: ZyncOpsDistAjax.nonce,
            order_id: orderId,
            user_id: userId
        }, function (response) {
            if (response.success) {
                $button.text("Assigned");
            } else {
                $button.text("Failed");
            }
        }).fail(function () {
            $button.text("Error");
        }).always(function () {
            // Reset after 3 seconds
            setTimeout(() => {
                $button.text("Save").prop('disabled', true);
            }, 3000);
        });
    });

    $('.user-check').on('change', function (e) {
        e.preventDefault();

        const selectedUserIds = [];

        $('.user-check:checked').each(function () {
            selectedUserIds.push(parseInt($(this).val()));
        });

        console.log('Currently Selected User IDs:', selectedUserIds);

        $.post(ZyncOpsDistAjax.ajax_url, {
            action: 'save_order_distibutor',
            security: ZyncOpsDistAjax.save_users,
            users: selectedUserIds
        }, function (response) {
            console.log(response);
            $('.zyncops-rsp-msg').text(response.data);
            if(response.success){
                $('.zyncops-rsp-msg').css('color', 'green');
            }else{
                $('.zyncops-rsp-msg').css('color', 'red');
            }
        }).fail(() => {
            $('.zyncops-rsp-msg').css('color', 'red');
        }).always(() => {
            setTimeout(() => {
                $('.zyncops-rsp-msg').text("");
            }, 3000);
        });
    });

    $('.zyncops-check-all').on('change', function (e) {
        e.preventDefault();
        
        const checkbox = (this);
        let selectedUserIds = [];

        $('.user-check').each(function () {
            $(this).prop('checked',checkbox.checked);
            selectedUserIds.push(parseInt($(this).val()));
        });
        
        if(!checkbox.checked){
            selectedUserIds = [];
        }
        
        console.log('Currently Selected User IDs:', selectedUserIds);

        $.post(ZyncOpsDistAjax.ajax_url, {
            action: 'save_order_distibutor',
            security: ZyncOpsDistAjax.save_users,
            users: selectedUserIds
        }, function (response) {
            console.log(response);
            $('.zyncops-rsp-msg').text(response.data);
            if(response.success){
                $('.zyncops-rsp-msg').css('color', 'green');
            }else{
                $('.zyncops-rsp-msg').css('color', 'red');
            }
        }).fail(() => {
            $('.zyncops-rsp-msg').css('color', 'red');
        }).always(() => {
            setTimeout(() => {
                $('.zyncops-rsp-msg').text("");
            }, 3000);
        });
    });

});
