jQuery(document).ready(function ($) {
    console.log("ZyncOps JS loaded");
    $('.zyncops-send-to-courier').on('click', function (e) {
        e.preventDefault(); // 👈 Prevent page refresh
        console.log("ZyncOps JS btn clicked");

        const orderId = $(this).data('order-id');

        if (!confirm('Are you sure you want to send this order to courier?')) {
            return;
        }

        $.post(ZyncOpsAjax.ajax_url, {
            action: 'send_order_to_courier',
            nonce: ZyncOpsAjax.nonce,
            order_id: orderId
        }, function (response) {
            if (response.success) {
                alert(`✅ ${response.data.message}\n📦 Tracking ID: ${response.data.tracking_id}`);
                location.reload(); // Optional: reload to update tracking info
            } else {
                alert(` Failed to send order: ${JSON.stringify(response.data)}`);
            }
        });
    });

    $('.zyncops-track-courier-parcel').on('click', function (e) {
        e.preventDefault(); // 👈 Prevent page refresh

        const orderId = $(this).data('order-id');

        $.post(ZyncOpsAjax.ajax_url, {
            action: 'track_parcel',
            nonce: ZyncOpsAjax.track,
            order_id: orderId
        }, function (response) {
            if (response.success) {
                const body = response.data;
            
                if (body.tracking) {
                    const tracking = body.tracking;
                    if (tracking.length > 0) {
                        alert(tracking[tracking.length - 1].desc);
                    } else {
                        alert("No tracking data found.");
                    }
                } else if (body.message) {
                    alert(body.message);
                } else {
                    alert("No data found to display.");
                }
            } else {
                alert(response.data ? response.data:`Something went wrong. Please try again.`);
            }
        });
    });
});
