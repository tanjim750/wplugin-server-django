jQuery(document).ready(function ($) {
    $('.restrict_user').on('click', function () {
        let button = $(this);
        
        let user_action = $(this).attr('data-action');
        let user = $(this).data('user');
        
        console.log(user_action);

        $.post(ZyncOpsRstnAjax.ajax_url, {
            action: 'save_order_restriction',
            security: ZyncOpsRstnAjax.nonce,
            user_action: user_action,
            user: user
        }, function (response) {
            console.log(response);
            if(response.data.success){
                button.text(response.data.text);
                button.attr('data-action', response.data.action);
                
            }else{
                button.text("Failed");
            }
        }).fail(() => {
            button.text("Failed");
        })
    });

});
