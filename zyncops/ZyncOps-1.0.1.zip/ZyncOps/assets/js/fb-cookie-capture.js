function getCookie(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    if (match) return match[2];
    return null;
}

document.addEventListener('DOMContentLoaded', function () {
    const fbp = getCookie('_fbp');
    const fbc = getCookie('_fbc');

    const form = document.querySelector('form.checkout');
    if (form) {
        if (fbp && !form.querySelector('input[name="fbp"]')) {
            form.insertAdjacentHTML('beforeend', `<input type="hidden" name="fbp" value="${fbp}">`);
        }
        if (fbc && !form.querySelector('input[name="fbc"]')) {
            form.insertAdjacentHTML('beforeend', `<input type="hidden" name="fbc" value="${fbc}">`);
        }
    }
});
