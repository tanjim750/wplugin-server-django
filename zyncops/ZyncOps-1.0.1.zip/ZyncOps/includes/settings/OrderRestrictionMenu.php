<?php

class OrderRestrictionMenu
{
    public function init_action()
    {
        add_action('admin_menu', [$this, 'menu_option']);
        add_action('admin_init', [$this, 'register_settings']);

        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_save_order_restriction', [$this, 'ajex_order_restriction']);
    }

    public function menu_option()
    {
        // Submenu: Order Limit
        add_submenu_page(
            'zyncops-settings',
            'Order Restriction',
            'Order Restriction',
            'manage_options',
            'zyncops-settings-order-restriction',
            [$this, 'order_restriction_page']
        );
    }

    public function register_settings()
    {
        // order limit
        register_setting('order_limit_group', 'order_limit_enabled');
        register_setting('order_limit_group', 'order_limit_per_day');

        add_settings_section(
            'order_limit_section',
            'Daily Order Restriction',
            null,
            'zyncops-settings-order-limit'
        );

        add_settings_field(
            'order_limit_enabled',
            'Enable Order Limit',
            function () {
                $enabled = get_option('order_limit_enabled', 'no');
                ?>
            <label>
                <input type="radio" name="order_limit_enabled" value="yes" <?php checked($enabled, 'yes'); ?>> Enable
            </label><br>
            <label>
                <input type="radio" name="order_limit_enabled" value="no" <?php checked($enabled, 'no'); ?>> Disable
            </label>
            <?php
            },
            'zyncops-settings-order-limit',
            'order_limit_section'
        );

        add_settings_field(
            'order_limit_per_day',
            'Orders Allowed Per Day',
            function () {
                $limit = get_option('order_limit_per_day', 1);
                echo '<input type="number" name="order_limit_per_day" value="' . esc_attr($limit) . '" min="1">';

            },
            'zyncops-settings-order-limit',
            'order_limit_section'
        );
    }

    public function order_restriction_page()
    {
        ?>
        <div class="wrap">
            <h1>Order Restriction Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('order_limit_group');
                do_settings_sections('zyncops-settings-order-limit');
                submit_button();
                ?>
            </form>

            <?php
            $is_enabled = get_option('zyncops_enabled', 'yes');
            $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');

            if ($is_enabled != 'no' && $is_licence_valid != 'no') {
                echo '<h1>User Order History</h1>';
                $this->user_order_and_revenue_table();
            }
            ?>

        </div>
        <?php
    }

    public function user_order_and_revenue_table()
    {
        $data = $this->aggregate_orders_by_user_or_ip();
        $block_user_list = get_option('zyncops_order_blocked_user_list', []);

        echo '<div class="zyncops-table-container">';
        echo '<h4 class="zyncops-rsp-msg"></h4>';
        echo '<table class="zyncops-table">';
        echo '<thead>
                <tr>
                    <th>Name</th>
                    <th>Number</th>
                    <th>IP</th>
                    <th>Orders</th>
                    <th>Cancelled</th>
                    <th>Returned</th>
                    <th>Delivered</th>
                    <th>Success Ratio</th>
                    <th>Action</th>
                </tr>
              </thead>
              <tbody>';

        foreach ($data as $key => $d) {
            echo '<tr>';
            echo '<td>' . esc_html($d['name']) . '</td>';
            echo '<td>' . esc_html($d['number']) . '</td>';
            echo '<td>' . esc_html($d['ip']) . '</td>';
            echo '<td>' . esc_html($d['total_orders']) . ' (' . wc_price($d['total_amount']) . ')</td>';
            echo '<td>' . esc_html($d['cancelled_orders']) . ' (' . wc_price($d['cancelled_amount']) . ')</td>';
            echo '<td>' . esc_html($d['returned_orders']) . ' (' . wc_price($d['returned_amount']) . ')</td>';
            echo '<td>' . esc_html($d['delivered_orders']) . ' (' . wc_price($d['delivered_amount']) . ')</td>';
            echo '<td>' . esc_html($d['success_ratio']) . '%</td>';
            if (
                in_array($d['ip'], $block_user_list)
                || in_array($key, $block_user_list)
            ) {
                echo '<td>
                    <button class="restrict_user" data-action="unblock" data-user="' . $key . '">Unblock</button>
                </td>';
            } else {
                echo '<td>
                    <button class="restrict_user" data-action="block" data-user="' . $key . '">Block</button>
                </td>';
            }
            echo '</tr>';
        }

        echo '</tbody></table></div>';
    }


    public function aggregate_orders_by_user_or_ip()
    {
        $args = [
            'limit' => -1,
            'status' => ['processing', 'completed', 'cancelled', 'refunded', 'on-hold', 'pending', 'failed']
        ];

        $orders = wc_get_orders($args);
        $result = [];

        foreach ($orders as $order) {
            if (!$order instanceof WC_Order) {
                continue; // Skip if somehow not a WC_Order
            }

            $user_id = $order->get_user_id();
            $ip = $order->get_customer_ip_address();

            // Use user ID if available, otherwise fallback to IP
            $key = $user_id ? 'user_' . $user_id : 'ip_' . $ip;

            if (!isset($result[$key])) {
                $result[$key] = [
                    'name' => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
                    'number' => $order->get_billing_phone(),
                    'ip' => $ip,
                    'user_id' => $user_id,
                    'total_orders' => 0,
                    'total_amount' => 0,
                    'returned_orders' => 0,
                    'returned_amount' => 0,
                    'cancelled_orders' => 0,
                    'cancelled_amount' => 0,
                    'delivered_orders' => 0,
                    'delivered_amount' => 0,
                ];
            }

            $amount = $order->get_total();
            $status = $order->get_status();

            $result[$key]['total_orders']++;
            $result[$key]['total_amount'] += $amount;

            if (in_array($status, ['refunded', 'returned'])) {
                $result[$key]['returned_orders']++;
                $result[$key]['returned_amount'] += $amount;
            } elseif (in_array($status, ['cancelled', 'failed'])) {
                $result[$key]['cancelled_orders']++;
                $result[$key]['cancelled_amount'] += $amount;
            } elseif ($status === 'completed') {
                $result[$key]['delivered_orders']++;
                $result[$key]['delivered_amount'] += $amount;
            }
        }

        // Add success ratio for each user
        foreach ($result as &$entry) {
            $entry['success_ratio'] = $entry['total_orders'] > 0
                ? round(($entry['delivered_orders'] / $entry['total_orders']) * 100, 2)
                : 0;
        }

        return $result;
    }

    public function enqueue_scripts($hook)
    {
        wp_enqueue_script(
            'zyncops-order-restriction-script',
            plugins_url('assets/js/zyncops-restriction.js', dirname(__DIR__, 2) . '/zyncops.php'),
            ['jquery'],
            null,
            true
        );

        wp_localize_script(
            'zyncops-order-restriction-script',
            'ZyncOpsRstnAjax',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('save_order_restriction_nonce'),
            ]
        );
    }

    public function ajex_order_restriction()
    {

        check_ajax_referer('save_order_restriction_nonce', 'security');

        if (!current_user_can('administrator')) {
            wp_send_json_error([
                'success' => false,
                'message' => 'Do not have the access to assign order.'
            ]);
        }

        $action = $_POST['user_action'] ?? '';
        $user = $_POST['user'] ?? '';
        $block_user_list = get_option('zyncops_order_blocked_user_list', []);

        if (!$action || !$user) {
            wp_send_json_error([
                'success' => false,
                'message' => 'Invalid request.'
            ]);
        }

        if ($action == 'block') {
            if (!in_array($user, $block_user_list)) {
                $block_user_list[] = $user;
                update_option('zyncops_order_blocked_user_list', $block_user_list);
                wp_send_json_success([
                    'success' => true,
                    'action' => 'unblock',
                    'text' => 'Unblock',
                ]);
            }
        } else if ($action == 'unblock') {
            if (($key = array_search($user, $block_user_list)) !== false) {
                unset($block_user_list[$key]);
                $block_user_list = array_values($block_user_list); // reindex array
                update_option('zyncops_order_blocked_user_list', $block_user_list);
                wp_send_json_success([
                    'success' => true,
                    'action' => 'block',
                    'text' => 'Block'
                ]);
            }
        }

        wp_send_json_error([
            'success' => false,
            'message' => 'An unknown error.'
        ]);
        wp_die(); // good practice after wp_send_json_*
    }

}