<?php

class MenuSettings
{
    private $base_url = 'https://d6c8-202-134-14-141.ngrok-free.app/';
    public function addSettingsPage()
    {
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_init', [$this, 'register_courier_credentials_settings']);
        add_action('update_option_zyncops_licence_key', [$this, 'handle_license_key_change'], 10, 2);
    }



    public function register_settings()
    {
        // Register options
        register_setting('zyncops_settings_group', 'zyncops_licence_key');
        register_setting('zyncops_settings_group', 'zyncops_enabled');

        register_setting('zyncops_courier_conf_group', 'courier_manager_selected_provider');
        register_setting('zyncops_courier_conf_group', 'zyncops_courier_enabled');
        register_setting('zyncops_courier_conf_group', 'courier_test_enabled');

        // Section
        add_settings_section('courier_settings_section', 'Courier Configuration', null, 'zyncops-courier-configaration');
        add_settings_section('zyncops_settings_section', 'ZyncOps Configuration', null, 'zyncops-settings');


        add_settings_field(
            'zyncops_enabled',
            'Enable ZyncOps',
            function () {
                $enabled = get_option('zyncops_enabled', 'yes');
                ?>
            <label>
                <input type="radio" name="zyncops_enabled" value="yes" <?php checked($enabled, 'yes'); ?>> Enable
            </label><br>
            <label>
                <input type="radio" name="zyncops_enabled" value="no" <?php checked($enabled, 'no'); ?>> Disable
            </label>
            <?php
            },
            'zyncops-settings',
            'zyncops_settings_section'
        );

        // Courier licence key field
        add_settings_field(
            'zyncops_licence_key',
            'Licence Key',
            function () {
                $value = get_option('zyncops_licence_key', '');
                $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');
                echo '<input type="text" name="zyncops_licence_key" value="' . esc_attr($value) . '" class="regular-text">';
                if ($is_licence_valid == 'no') {
                    echo '</br><span class="zyncops-error-msg">Invalid licence key. Please contact with <a target="_blank" href="https://www.facebook.com/trizyncsolution">Trizync.</a></span>';
                }
            },
            'zyncops-settings',
            'zyncops_settings_section'
        );


        // Enable/Disable field
        add_settings_field(
            'zyncops_courier_enabled',
            'Enable Courier Integration',
            function () {
                $enabled = get_option('zyncops_courier_enabled', 'no');
                ?>
            <label>
                <input type="radio" name="zyncops_courier_enabled" value="yes" <?php checked($enabled, 'yes'); ?>> Enable
            </label><br>
            <label>
                <input type="radio" name="zyncops_courier_enabled" value="no" <?php checked($enabled, 'no'); ?>> Disable
            </label>
            <?php
            },
            'zyncops-courier-configaration',
            'courier_settings_section'
        );


        // Courier selection field
        add_settings_field(
            'courier_manager_selected_provider',
            'Select Courier',
            function () {
                $selected = get_option('courier_manager_selected_provider', 'redx');
                ?>
            <select name="courier_manager_selected_provider">
                <option value="redx" <?php selected($selected, 'redx'); ?>>Redx</option>
                <option value="steadfast" <?php selected($selected, 'steadfast'); ?>>Steadfast</option>
                <option value="pathao" <?php selected($selected, 'pathao'); ?>>Pathao</option>
            </select>
            <?php
            },
            'zyncops-courier-configaration',
            'courier_settings_section'
        );

        // test case 
        add_settings_field(
            'courier_test_enabled',
            'Enable test courier',
            function () {
                $enabled = get_option('courier_test_enabled', 'no');
                ?>
            <label>
                <input type="radio" name="courier_test_enabled" value="yes" <?php checked($enabled, 'yes'); ?>> Enabled
            </label><br>
            <label>
                <input type="radio" name="courier_test_enabled" value="no" <?php checked($enabled, 'no'); ?>> Disabled
            </label>
            <?php
            },
            'zyncops-courier-configaration',
            'courier_settings_section'
        );

    }

    public function register_courier_credentials_settings()
    {
        // Redx Settings
        register_setting('redx_credentials_group', 'redx_api_key');

        add_settings_section(
            'redx_credentials_section',
            'Redx API Configuration',
            null,
            'zyncops-settings-redx'
        );

        add_settings_field(
            'redx_api_key',
            'API Key',
            function () {
                $value = get_option('redx_api_key', '');
                echo '<input type="text" name="redx_api_key" value="' . esc_attr($value) . '" class="regular-text">';
            },
            'zyncops-settings-redx',
            'redx_credentials_section'
        );


        // Steadfast Settings
        register_setting('steadfast_credentials_group', 'courier_manager_steadfast_api_key');
        register_setting('steadfast_credentials_group', 'courier_manager_steadfast_secret_key');

        add_settings_section(
            'steadfast_credentials_section',
            'Steadfast API Configuration',
            null,
            'zyncops-settings-steadfast'
        );

        add_settings_field(
            'courier_manager_steadfast_api_key',
            'API Key',
            function () {
                $value = get_option('courier_manager_steadfast_api_key', '');
                echo '<input type="text" name="courier_manager_steadfast_api_key" value="' . esc_attr($value) . '" class="regular-text">';
            },
            'zyncops-settings-steadfast',
            'steadfast_credentials_section'
        );

        add_settings_field(
            'courier_manager_steadfast_secret_key',
            'Secret Key',
            function () {
                $value = get_option('courier_manager_steadfast_secret_key', '');
                echo '<input type="text" name="courier_manager_steadfast_secret_key" value="' . esc_attr($value) . '" class="regular-text">';
            },
            'zyncops-settings-steadfast',
            'steadfast_credentials_section'
        );

        // Pathao Settings
        register_setting('pathao_credentials_group', 'courier_manager_pathao_client_id');
        register_setting('pathao_credentials_group', 'courier_manager_pathao_client_secret');
        register_setting('pathao_credentials_group', 'courier_manager_pathao_username');
        register_setting('pathao_credentials_group', 'courier_manager_pathao_password');

        add_settings_section(
            'pathao_credentials_section',
            'Pathao API Configuration',
            null,
            'zyncops-settings-pathao'
        );

        add_settings_field(
            'courier_manager_pathao_client_id',
            'Client ID',
            function () {
                $value = get_option('courier_manager_pathao_client_id', '');
                echo '<input type="text" name="courier_manager_pathao_client_id" value="' . esc_attr($value) . '" class="regular-text">';
            },
            'zyncops-settings-pathao',
            'pathao_credentials_section'
        );

        add_settings_field(
            'courier_manager_pathao_client_secret',
            'Client Secret',
            function () {
                $value = get_option('courier_manager_pathao_client_secret', '');
                echo '<input type="text" name="courier_manager_pathao_client_secret" value="' . esc_attr($value) . '" class="regular-text">';
            },
            'zyncops-settings-pathao',
            'pathao_credentials_section'
        );

        add_settings_field(
            'courier_manager_pathao_username',
            'Username',
            function () {
                $value = get_option('courier_manager_pathao_username', '');
                echo '<input type="text" name="courier_manager_pathao_username" value="' . esc_attr($value) . '" class="regular-text">';
            },
            'zyncops-settings-pathao',
            'pathao_credentials_section'
        );

        add_settings_field(
            'courier_manager_pathao_password',
            'Password',
            function () {
                $value = get_option('courier_manager_pathao_password', '');
                echo '<input type="text" name="courier_manager_pathao_password" value="' . esc_attr($value) . '" class="regular-text">';
            },
            'zyncops-settings-pathao',
            'pathao_credentials_section'
        );


        // Cart Abandoned Settings
        register_setting('cart_abandoned_group', 'cart_abandoned_enabled');
        register_setting('cart_abandoned_group', 'cart_abandoned_time');

        add_settings_section(
            'cart_abandoned_section',
            'Cart Abandonment Tracking',
            null,
            'zyncops-settings-abandoned-cart'
        );

        add_settings_field(
            'cart_abandoned_enabled',
            'Enable Tracking',
            function () {
                $value = get_option('cart_abandoned_enabled', 'yes');
                echo '<select name="cart_abandoned_enabled">
                        <option value="yes" ' . selected($value, 'yes', false) . '>Enabled</option>
                        <option value="no" ' . selected($value, 'no', false) . '>Disabled</option>
                    </select>';
            },
            'zyncops-settings-abandoned-cart',
            'cart_abandoned_section'
        );

        add_settings_field(
            'cart_abandoned_time',
            'Time to Mark as Abandoned (in minutes)',
            function () {
                $value = get_option('cart_abandoned_time', 30);
                echo '<input type="number" name="cart_abandoned_time" value="' . esc_attr($value) . '" min="1" step="1"> minutes';

            },
            'zyncops-settings-abandoned-cart',
            'cart_abandoned_section'
        );


        // order flow tracking Settings
        register_setting('zyncops_order_flow_group', 'zyncops_order_flow_enabled');
        register_setting('zyncops_order_flow_group', 'zyncops_facebook_pixel_id');
        register_setting('zyncops_order_flow_group', 'zyncops_facebook_pixel_token');
        register_setting('zyncops_order_flow_group', 'zyncops_facebook_pixel_test_code');

        add_settings_section(
            'zyncops_order_flow_section',
            'Order Flow Tracking',
            null,
            'zyncops-settings-order-flow'
        );

        add_settings_field(
            'zyncops_order_flow_enabled',
            'Enable Order Flow Tracking',
            function () {
                $value = get_option('zyncops_order_flow_enabled', 'no');
                echo '<select name="zyncops_order_flow_enabled">
                        <option value="yes" ' . selected($value, 'yes', false) . '>Enabled</option>
                        <option value="no" ' . selected($value, 'no', false) . '>Disabled</option>
                    </select>';
            },
            'zyncops-settings-order-flow',
            'zyncops_order_flow_section'
        );

        add_settings_field(
            'zyncops_facebook_pixel_id',
            'Facebook Pixel ID',
            function () {
                $value = get_option('zyncops_facebook_pixel_id', '');
                echo '<input type="text" name="zyncops_facebook_pixel_id" value="' . esc_attr($value) . '" class="regular-text">';
            },
            'zyncops-settings-order-flow',
            'zyncops_order_flow_section'
        );

        add_settings_field(
            'zyncops_facebook_pixel_token',
            'Facebook Pixel Access Token',
            function () {
                $value = get_option('zyncops_facebook_pixel_token', '');
                echo '<input type="text" name="zyncops_facebook_pixel_token" value="' . esc_attr($value) . '" class="regular-text">';
            },
            'zyncops-settings-order-flow',
            'zyncops_order_flow_section'
        );

        add_settings_field(
            'zyncops_facebook_pixel_test_code',
            'Facebook Pixel Test Event Code',
            function () {
                $value = get_option('zyncops_facebook_pixel_test_code', '');
                echo '<input type="text" name="zyncops_facebook_pixel_test_code" value="' . esc_attr($value) . '" class="regular-text">';
            },
            'zyncops-settings-order-flow',
            'zyncops_order_flow_section'
        );


    }

    public function handle_license_key_change($old_value, $new_value)
    {
        if ($old_value !== $new_value) {


            $parsed = parse_url(site_url());
            $domain = $parsed['host'];

            $payload = [
                'license_key' => $new_value,
                'domain' => $domain,
            ];

            $response = wp_remote_post(BASE_URL . 'verify-license/', [
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'body' => json_encode($payload),
                'timeout' => 15,
            ]);

            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);

                if (isset($data['success']) && $data['success'] && $data['valid']) {

                    update_option('zyncops_licence_key_valid', 'yes');
                } else {

                    update_option('zyncops_licence_key_valid', 'no');
                }
            } else {
                update_option('zyncops_licence_key_valid', 'no');
            }
        }
    }


}