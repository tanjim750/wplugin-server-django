<?php

class OrderDistMenu
{
    public function init_action()
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'register_settings']);

        // add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_save_order_distibutor', [$this, 'save_distributor_id']);
    }

    public function register_settings()
    {
        register_setting('zyncops_order_distribution_group', 'zyncops_order_distribution_option');

        add_settings_section(
            'zyncops_order_distribution_section',
            'Order Distribution Mode',
            null,
            'zyncops-settings-order-distribution'
        );

        add_settings_field(
            'zyncops_order_distribution_option',
            'Order Distribution Mode',
            function () {
                $value = get_option('zyncops_order_distribution_option', 'manual');
                echo '<select name="zyncops_order_distribution_option">
                        <option value="disabled" ' . selected($value, 'disabled', false) . '>Disabled</option>
                        <option value="manual" ' . selected($value, 'manual', false) . '>Manual</option>
                        <option value="auto" ' . selected($value, 'auto', false) . '>Auto</option>
                    </select>';
            },
            'zyncops-settings-order-distribution',
            'zyncops_order_distribution_section'
        );
    }

    public function menu()
    {
        add_submenu_page(
            'zyncops-settings',
            'Order Distribution Settings',
            'Order Distribution Settings',
            'manage_options',
            'zyncops-settings-order-distribution',
            [$this, 'order_distribution_settings_page']
        );

        // add_submenu_page(
        //     'woocommerce',                    // Parent slug: WooCommerce main menu
        //     'Assigned Order',                 // Page title
        //     'Assigned Order',                 // Menu title
        //     'manage_woocommerce',            // Capability
        //     'wc-assigned-order',             // Menu slug
        //     [$this, 'render_wc_cart_assigned_order_page'] // Callback function
        // );
    }

    public function order_distribution_settings_page()
    {
        ?>
        <div class="wrap">
            <h1>Order Distribution Settings</h1>

            <form method="post" action="options.php">
                <?php
                settings_fields('zyncops_order_distribution_group');
                do_settings_sections('zyncops-settings-order-distribution');
                submit_button();
                ?>
            </form>

            <h2>Shop Managers Overview</h2>
            <?php $this->distribution_table(); ?>
        </div>
        <?php
    }

    public function distribution_table()
    {
        $users = get_users([
            'role__not_in' => ['customer', 'subscriber', 'editor'],
        ]);

        $selected_users = get_option('zyncops_selected_distributors_id', []);


        echo '<div class="zyncops-table-container">';
        echo '<h4 class="zyncops-rsp-msg"></h4>';
        echo '<table class="zyncops-table">';
        echo '<thead>
                <tr>
                    <th><input class="zyncops-check-all" type="checkbox" /></th>
                    <th>Name</th>
                    <th>Assigned</th>
                    <th>Completed</th>
                    <th>Cancelled</th>
                    <th>Refunded</th>
                    <th>Other</th>
                    <th>Success Ratio</th>
                </tr>
              </thead>
              <tbody>';

        foreach ($users as $user) {
            $assigned = $this->get_order_count_and_total($user->ID);
            $completed = $this->get_order_count_and_total($user->ID, 'completed');
            $cancelled = $this->get_order_count_and_total($user->ID, 'cancelled');
            $refunded = $this->get_order_count_and_total($user->ID, 'refunded');

            $other_count = $assigned['count'] - ($completed['count'] + $cancelled['count'] + $refunded['count']);
            $other_amount = $assigned['amount'] - ($completed['amount'] + $cancelled['amount'] + $refunded['amount']);
            $success_ratio = $assigned['count'] > 0 ? round(($completed['count'] / $assigned['count']) * 100, 2) . '%' : 'N/A';

            echo '<tr>';
            echo '<td><input type="checkbox" class="user-check" name="selected_users[]" value="' . esc_attr($user->ID) . '" ' . (in_array((string) $user->ID, $selected_users, true) ? 'checked' : '') . '></td>';
            echo '<td>' . esc_html($user->display_name) . '</td>
                    <td>' . $assigned['count'] . ' (' . wc_price($assigned['amount']) . ')</td>
                    <td>' . $completed['count'] . ' (' . wc_price($completed['amount']) . ')</td>
                    <td>' . $cancelled['count'] . ' (' . wc_price($cancelled['amount']) . ')</td>
                    <td>' . $refunded['count'] . ' (' . wc_price($refunded['amount']) . ')</td>
                    <td>' . $other_count . ' (' . wc_price($other_amount) . ')</td>
                    <td>' . $success_ratio . '</td>
                </tr>';
        }

        echo '</tbody></table></div>';
    }

    public function render_wc_cart_assigned_order_page()
    {
        list($original_user, $admin_user) = $this->zyncops_get_original_and_admin_user();
        if (!current_user_can('administrator')) {
            zyncops_switch_to_user($admin_user);
        }

        $args = [
            'limit' => -1,
            'return' => 'ids', // Just get order IDs for performance
        ];

        $orders = wc_get_orders($args);
        $user_id = get_current_user_id();


        echo '<h4>Assigned Orders</h4>';
        echo '<div class="zyncops-table-container">';
        echo '<table class="zyncops-table">';
        echo '<thead>
                <tr>
                    <th>Order</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Total</th>
                    <th>Zyncops</th>';

        if (current_user_can('administrator')) {
            echo '<th>Distiributon</th>';
        }

        echo '</tr>
              </thead>
              <tbody>';

        foreach ($orders as $order_id) {
            if (!$order instanceof WC_Order) {
                continue; // Skip if somehow not a WC_Order
            }

            $assigned = get_post_meta($order_id, 'zyncops_assigned_distributor_id', true);
            $order = wc_get_order($order_id);

            $total_amount = $order->get_total();
            $customer_name = $order->get_formatted_billing_full_name(); // Full name from billing
            $order_date = $order->get_date_created()->date('Y-m-d H:i:s'); // Order date
            $order_status = wc_get_order_status_name($order->get_status()); // Human-readable status


            if ((int) $assigned === (int) $user_id) {
                echo '<tr>';
                echo '<td> #' . esc_html($assigned) . ' ' . esc_html($user_id) . '</td>
                        <td>' . esc_html($order_date) . '</td>
                        <td>' . esc_html($order_status) . '</td>
                        <td>' . esc_html($total_amount) . '</td>
                        <td>' . $this->render_courier_column($order_id) . '</td>';

                if (current_user_can('administrator')) {
                    echo '<td>' . $this->render_distribution_column($order_id) . '</td>';
                }
                echo '</tr>';
            }
        }

        if (!current_user_can('administrator')) {
            zyncops_switch_to_user($original_user);
        }
    }

    private function get_order_count_and_total($user_id, $status = null)
    {
        $args = [
            'limit' => -1,
            'status' => $status ? 'wc-' . sanitize_title($status) : '',
            'return' => 'ids', // Just get order IDs for performance
        ];

        $orders = wc_get_orders($args);
        $total_amount = 0;
        $matched_count = 0;

        foreach ($orders as $order_id) {
            $assigned = get_post_meta($order_id, 'zyncops_assigned_distributor_id', true);
            if ((int) $assigned === (int) $user_id) {
                $order = wc_get_order($order_id);
                $total_amount += $order->get_total();
                $matched_count++;
            }
        }

        return [
            'count' => $matched_count,
            'amount' => $total_amount,
        ];
    }

    public function render_courier_column($post_id)
    {
        $tracking = get_post_meta($post_id, 'zyncops_tracking_id', true);
        $selected_provider = get_option('courier_manager_selected_provider', false);
        $order = wc_get_order($post_id);


        if ($tracking) {
            if ($order) {
                return '<button type="button" class="button zyncops-track-parcel" data-order-id="' . esc_attr($post_id) . '">Track Parcel</button>';
            } else {
                return '<em>Order ID not found</em>';
            }

        } else {
            if (!$tracking && $selected_provider && $order && ($order->has_status(['processing', 'on-hold', 'pending']))) {
                return '<button type="button" class="button zyncops-send-to-courier" data-order-id="' . esc_attr($post_id) . '">Send to ' . $selected_provider . '</button>';
            }
        }

    }

    public function render_distribution_column($order_id)
    {
        // Get assigned user ID from order meta
        $assigned_user_id = get_post_meta($order_id, 'zyncops_assigned_distributor_id', true);
        $order = wc_get_order($order_id);

        if (!$order instanceof WC_Order) {
            return; // Skip if somehow not a WC_Order
        }

        $status = $order->get_status();

        $users = get_users([
            'exclude' => [get_current_user_id()],
            'role__not_in' => ['customer', 'subscriber', 'editor'],
        ]);

        $render = '';

        if (in_array($status, ['completed', 'refunded', 'cancelled']) && $assigned_user_id) {
            $render = $render . '<div class="zyncops-distribution">
                <select disabled class="zyncops-distribution-user" data-order-id="' . esc_attr($order_id) . '">
                <option disabled ' . selected(empty($assigned_user_id), true, false) . '>None</option>';

            // assined user
            $render = $render . '<option value="' . $assigned_user_id . '" selected>' . get_the_author_meta('display_name', $assigned_user_id) . '</option>';

            $render = $render . '</select>';
            $render = $render . '</div>';

            return;
        }

        $render = $render . '<div class="zyncops-distribution">
        <select class="zyncops-distribution-user" data-order-id="' . esc_attr($order_id) . '">
        <option disabled ' . selected(empty($assigned_user_id), true, false) . '>None</option>';

        // Self option
        $render = $render . '<option value="' . esc_attr(get_current_user_id()) . '" ' . selected($assigned_user_id, get_current_user_id(), false) . '>Self</option>';

        // All other users
        foreach ($users as $user) {
            $render = $render . '<option value="' . esc_attr($user->ID) . '" ' . selected($assigned_user_id, $user->ID, false) . '>' . esc_html($user->display_name) . '</option>';
        }

        $render = $render . '</select>';
        $render = $render . '<button type="button" disabled class="zyncops-distribution-save" data-order-id="' . esc_attr($order_id) . '">Save</button>';
        $render = $render . '</div>';

        return $render;

    }


    public function enqueue_scripts($hook)
    {

        // ❱❱ Optional: restrict to the order list / edit screen only.
        // if ( $hook !== 'edit.php' && $hook !== 'post.php' ) return;

        wp_enqueue_script(
            'zyncops-admin-distribution-js',
            plugins_url('assets/js/zyncops-distibution.js', dirname(__DIR__, 2) . '/zyncops.php'),
            ['jquery'],
            null,
            true
        );

        wp_localize_script(
            'zyncops-admin-distribution-js',
            'ZyncOpsDistAjax',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'save_users' => wp_create_nonce('save_order_distibutor_nonce'),
            ]
        );
    }


    public function save_distributor_id()
    {
        check_ajax_referer('save_order_distibutor_nonce', 'security');

        $users = $_POST['users'] ?? [];

        if (!is_array($users)) {
            wp_send_json_error('Invalid users format.');
        }

        update_option('zyncops_selected_distributors_id', $users);

        wp_send_json_success('Order distributor saved successfully.'); // return raw array back to JS
        wp_die();
    }


    function zyncops_get_original_and_admin_user()
    {
        $original_user_id = get_current_user_id();

        if (!$original_user_id) {
            return [null, null]; // Not logged in
        }

        $original_user = get_user_by('id', $original_user_id);

        // If current user is already an administrator, return the same for both
        if (in_array('administrator', $original_user->roles)) {
            return [$original_user, $original_user];
        }

        // Otherwise, get the first available admin user
        $admin_users = get_users([
            'role' => 'administrator',
            'number' => 1,
            'orderby' => 'ID',
            'order' => 'ASC',
        ]);

        $admin_user = !empty($admin_users) ? $admin_users[0] : null;

        return [$original_user, $admin_user];
    }

    function zyncops_switch_to_user($user)
    {
        if ($user instanceof WP_User) {
            wp_set_current_user($user->ID);
        } elseif (is_numeric($user)) {
            wp_set_current_user((int) $user);
        }
    }


}