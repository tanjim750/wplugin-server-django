<?php

class Settings
{
    public function __construct()
    {

    }
}