<?php

class CartAbandonedMenu
{
    public function init_action()
    {
        $is_enabled = get_option('zyncops_enabled', 'yes');
        $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');

        if ($is_enabled == 'no' || $is_licence_valid == 'no') {
            return;
        }

        add_action('admin_menu', [$this, 'menu_option']);

    }

    public function menu_option()
    {
        add_submenu_page(
            'woocommerce',                    // Parent slug: WooCommerce main menu
            'Cart Abandoned',                 // Page title
            'Cart Abandoned',                 // Menu title
            'manage_woocommerce',            // Capability
            'wc-cart-abandoned',             // Menu slug
            [$this, 'render_wc_cart_abandoned_page'] // Callback function
        );
    }

    public function render_wc_cart_abandoned_page()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'zyncops_abandoned_cart';

        // Get counts
        $abandoned_count = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE action = 'abandoned'");
        $converted_count = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE action = 'converted'");

        // Initialize amounts
        $abandoned_amount = 0;
        $converted_amount = 0;

        // Fetch and calculate total item value for abandoned carts
        $abandoned_rows = $wpdb->get_results("SELECT items FROM $table WHERE action = 'abandoned'");
        foreach ($abandoned_rows as $row) {
            $items = json_decode($row->items);
            if (!empty($items)) {
                foreach ($items as $item) {
                    $abandoned_amount += floatval($item->price ?? 0) * intval($item->quantity ?? 1);
                }
            }
        }

        // Fetch and calculate total item value for converted carts
        $converted_rows = $wpdb->get_results("SELECT items FROM $table WHERE action = 'converted'");
        foreach ($converted_rows as $row) {
            $items = json_decode($row->items);
            if (!empty($items)) {
                foreach ($items as $item) {
                    $converted_amount += floatval($item->price ?? 0) * intval($item->quantity ?? 1);
                }
            }
        }




        // Get all data
        $results = $wpdb->get_results("SELECT * FROM $table WHERE phone IS NOT NULL AND phone != '' ORDER BY created_at DESC");

        echo '<h2 class="zyncops-heading">🛒 Abandoned Cart Tracker</h2>';
        echo '<div class="zyncops-stats">';
        echo '
            <div class="cardm">
            <div class="card">
                <svg class="weather" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="100px" height="100px" viewBox="0 0 100 100" xml:space="preserve">  <image id="image0" width="100" height="100" x="0" y="0" href="https://cdn-icons-png.flaticon.com/512/18274/18274893.png"></image>
                </svg>
                <div class="main">' . $abandoned_count . '
                <div class="mainsub">Total Abandoned</div>
                </div>
                

            </div>
            </div>
        ';

        echo '
            <div class="cardm">
            <div class="card">
                <svg class="weather" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="100px" height="100px" viewBox="0 0 100 100" xml:space="preserve">  <image id="image0" width="100" height="100" x="0" y="0" href="https://cdn-icons-png.freepik.com/256/8426/8426066.png?semt=ais_hybrid"></image>
                </svg>
                <div class="main">' . wc_price($abandoned_amount) . '
                <div class="mainsub">Abandoned Amount</div>
                </div>

            </div>
            </div>
        ';

        echo '
            <div class="cardm">
            <div class="card">
                <svg class="weather" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="100px" height="100px" viewBox="0 0 100 100" xml:space="preserve">  <image id="image0" width="100" height="100" x="0" y="0" href="https://cdn-icons-png.flaticon.com/512/11804/11804457.png"></image>
                </svg>
                <div class="main">' . $converted_count .
            '<div class="mainsub">Total Converted</div>
                </div>

            </div>
            </div>
        ';

        echo '
            <div class="cardm">
            <div class="card">
                <svg class="weather" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="100px" height="100px" viewBox="0 0 100 100" xml:space="preserve">  <image id="image0" width="100" height="100" x="0" y="0" href="https://cdn-icons-png.flaticon.com/512/4213/4213898.png"></image>
                </svg>
                <div class="main">' . wc_price($converted_amount) . '
                <div class="mainsub">Converted Amount</div>
                </div>

            </div>
            </div>
        ';
        echo '</div>';

        echo '<div class="zyncops-table-container">';
        echo '<table class="zyncops-table">';
        echo '<thead>
                <tr>
                    <th>User</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Items</th>
                    <th>Completion</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Updated</th>
                </tr>
              </thead><tbody>';

        foreach ($results as $row) {
            $items = json_decode($row->items);
            $label = (strpos($row->user_identifier, 'session_') === 0) ? 'Guest' : 'User';

            if (empty($items)) {
                continue;
            }
            echo '<tr>';
            echo "<td>{$label}</td>";
            echo "<td>{$row->name}</td>";
            echo "<td>{$row->email}</td>";
            echo "<td>{$row->phone}</td>";
            echo "<td>{$row->address}</td>";
            echo "<td><pre style='white-space: pre-wrap; max-width: 300px;'>";
            foreach ($items as $item) {
                echo "Product: " . esc_html($item->name ?? 'N/A');
                echo " | Quantity: " . esc_html($item->quantity ?? 'N/A');
                echo " | Price: " . esc_html($item->price ?? 'N/A');
                echo "\n---------------------------\n";
            }
            echo "</pre></td>";
            echo "<td>{$row->completion_ratio}%</td>";
            echo "<td><span class='zyncops-badge {$row->action}'>{$row->action}</span></td>";
            echo "<td>{$row->created_at}</td>";
            echo "<td>{$row->updated_at}</td>";
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }


}