<?php

class OrderTracking
{
    public function init_action()
    {
        $is_enabled = get_option('zyncops_enabled', 'yes');
        $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');

        if ($is_enabled == 'no' || $is_licence_valid == 'no') {
            return;
        }

        add_filter('woocommerce_my_account_my_orders_columns', [$this, 'add_tracking_column'], 20);
        add_action('woocommerce_my_account_my_orders_column_zyncops_customer_tracking', [$this, 'render_tracking_column'], 20, 1);
        add_action('woocommerce_order_details_after_order_table', [$this, 'show_tracking_info_on_order_page']);

    }
    public function add_tracking_column($columns)
    {
        $columns['zyncops_customer_tracking'] = __('Tracking', 'your-textdomain');
        return $columns;
    }

    public function render_tracking_column($order)
    {
        $order_id = $order->get_id();
        $tracking_id = get_post_meta($order_id, 'zyncops_tracking_id', true);

        $result = $this->track_parcel($order_id);

        if (is_wp_error($result)) {
            echo '<em>Something went wrong.</em>';
        } else {
            $body = json_decode(wp_remote_retrieve_body($result), true);

            if (isset($body['tracking']) && is_array($body['tracking'])) {
                $tracking = $body['tracking'];
                if (count($tracking) > 0) {
                    echo '<em>' . esc_html($tracking[count($tracking) - 1]['desc']) . '</em>';
                } else {
                    echo '<em>No tracking updates yet.</em>';
                }
            } else {
                echo '<em>On Processing</em>';
            }
        }
    }

    public function track_parcel($order_id)
    {

        $license_key = get_option('zyncops_licence_key');
        $parsed = parse_url(site_url());
        $domain = $parsed['host']; // This gives you just "example.com"
        $platform = get_post_meta($order_id, 'courier_tracking_platform', true); // e.g., 'pathao'

        $credentials = [];

        if ($platform == 'redx') {
            $credentials['api_key'] = get_option('redx_api_key', '');
        } else if ($platform == 'steadfast') {
            $credentials['api_key'] = get_option('courier_manager_steadfast_api_key', '');
            $credentials['secret_key'] = get_option('courier_manager_steadfast_secret_key', '');
        } else if ($platform == 'pathao') {
            $credentials['client_id'] = get_option('courier_manager_pathao_client_id', '');
            $credentials['client_secret'] = get_option('courier_manager_pathao_client_secret', '');
            $credentials['username'] = get_option('courier_manager_pathao_username', '');
            $credentials['password'] = get_option('courier_manager_pathao_password', '');
        }

        $tracking_id = get_post_meta($order_id, 'zyncops_tracking_id', true);

        $payload = [
            'license_key' => $license_key,
            'domain' => $domain,
            'platform' => $platform,
            'credentials' => $credentials,
            'tracking_id' => $tracking_id,
            'test_mode' => true
        ];

        $response = wp_remote_post(BASE_URL . 'track-parcel/', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($payload),
            'timeout' => 30,
        ]);

        return $response;
    }

    public function show_tracking_info_on_order_page($order)
    {
        if (!$order instanceof WC_Order) {
            return;
        }

        $order_id = $order->get_id();
        $order_status = $order->get_status();
        $tracking_id = get_post_meta($order_id, 'zyncops_tracking_id', true);

        if (!$tracking_id) {
            return;
        }

        echo '<section class="woocommerce-order-tracking">';
        echo '<h2>Tracking Info</h2>';

        $result = $this->track_parcel($order_id);

        if (is_wp_error($result)) {
            echo '<p><em>Could not fetch tracking updates right now.</em></p>';
        } else {
            $body = json_decode(wp_remote_retrieve_body($result), true);

            if (isset($body['tracking']) && is_array($body['tracking']) && count($body['tracking']) > 0) {
                $tracking_updates = $body['tracking'];
                $count_idx = 1;
                echo '<div class="stepper-box">';
                foreach ($tracking_updates as $update) {
                    $message = esc_html($update['desc']);
                    $time = date('d M Y, h:i a', strtotime($update['created_at']));

                    if ($order_status == 'on-hold' || $order_status == 'pending') {
                        echo '
                            <div class="stepper-step stepper-pending">
                                <div class="stepper-circle">' . (string) $count_idx . '</div>
                                <div class="stepper-content">
                                <div class="stepper-title">' . $message . '</div>
                                <div class="stepper-status">Pending</div>
                                <div class="stepper-time">' . $time . '</div>
                                </div>
                            </div>
                        ';
                    } elseif ($order_status == 'completed') {
                        echo '
                            <div class="stepper-step stepper-completed">
                                <div class="stepper-circle">
                                <svg
                                    viewBox="0 0 16 16"
                                    class="bi bi-check-lg"
                                    fill="currentColor"
                                    height="16"
                                    width="16"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425z"
                                    ></path>
                                </svg>
                                </div>
                                <div class="stepper-line"></div>
                                <div class="stepper-content">
                                <div class="stepper-title">' . $message . '</div>
                                <div class="stepper-status">Completed</div>
                                <div class="stepper-time">' . $time . '</div>
                                </div>
                            </div>
                        ';
                    } else {
                        echo '
                            <div class="stepper-step stepper-active">
                                <div class="stepper-circle">' . (string) $count_idx . '</div>
                                <div class="stepper-line"></div>
                                <div class="stepper-content">
                                <div class="stepper-title">' . $message . '</div>
                                <div class="stepper-status">On the way</div>
                                <div class="stepper-time">' . $time . '</div>
                                </div>
                            </div>
                        ';
                    }
                }
                echo '</div>';
            } else {
                echo '<p><em>No tracking updates available yet.</em></p>';
            }
        }

        echo '</section>';

    }
}