<?php

class OrderLimit
{
    public function init_action()
    {
        $is_enabled = get_option('order_limit_enabled', 'yes');

        if ($is_enabled == 'yes') {
            add_action('woocommerce_checkout_process', [$this, 'order_limit']);
        }
    }


    function order_limit()
    {
        $is_enabled = get_option('order_limit_enabled', 'yes');
        $limit_per_day = intval(get_option('order_limit_per_day', 1));
        $blocked_user_list = get_option('zyncops_order_blocked_user_list', []);

        if ($is_enabled !== 'yes') {
            return;
        }

        $user_id = get_current_user_id();
        $user_ip = $_SERVER['REMOTE_ADDR'];

        if (
            in_array($user_ip, $blocked_user_list)
            || in_array('user_' . $user_id, $blocked_user_list)
        ) {
            wc_add_notice('Sorry,You can not order now.Please try again leter.', 'error');
            return;
        }

        $date_query = [
            'after' => date('Y-m-d 00:00:00'),
            'inclusive' => true,
        ];

        if ($user_id) {
            $args = [
                'customer_id' => $user_id,
                'limit' => -1,
                'return' => 'ids',
                'date_query' => [$date_query],
            ];
        } else {
            $args = [
                'limit' => -1,
                'meta_key' => '_customer_ip_address',
                'meta_value' => $user_ip,
                'return' => 'ids',
                'date_query' => [$date_query],
            ];
        }

        $orders = wc_get_orders($args);

        if (count($orders) >= $limit_per_day) {
            wc_add_notice('You have reached your order limit for today.', 'error');
        }
    }
}