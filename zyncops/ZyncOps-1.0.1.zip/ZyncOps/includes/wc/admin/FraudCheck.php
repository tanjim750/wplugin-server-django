<?php

class FraudCheck
{
    public function init_action()
    {
        $is_enabled = get_option('zyncops_courier_enabled', 'no');

        add_action('woocommerce_admin_order_data_after_billing_address', [$this, 'fraud_checker'], 10, 1);

        if ($is_enabled == 'no') {
            return;
        }

        if (function_exists('wc_get_container') && wc_get_container()->get(\Automattic\WooCommerce\Utilities\OrderUtil::class)->custom_orders_table_usage_is_enabled()) {
            // HPOS is enabled
            add_filter('woocommerce_shop_order_list_table_columns', [$this, 'add_order_column'], 20);
            add_action('woocommerce_shop_order_list_table_custom_column', [$this, 'render_order_column'], 10, 2);
        } else {
            // Standard order storage
            add_filter('manage_edit-shop_order_columns', [$this, 'add_order_column'], 20);
            add_action('manage_shop_order_posts_custom_column', [$this, 'render_order_column'], 10, 2);
        }
    }

    function fraud_checker($order)
    {
        if (!$order instanceof WC_Order) {
            return;
        }

        $phone = $order->get_billing_phone();
        $license_key = get_option('zyncops_licence_key');
        $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');
        $parsed = parse_url(site_url());
        $domain = $parsed['host'];

        if ($is_licence_valid == 'no') {
            echo '<div><strong>Fraud Check:</strong> Please activate your licence.</div>';
            return;
        }

        if (!$phone) {
            echo '<div><strong>Fraud Check:</strong> Missing phone number.</div>';
            return;
        }

        $api_url = BASE_URL . 'fraud-check/'; // Replace with your actual Django URL

        $response = wp_remote_post($api_url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => json_encode([
                'phone' => $phone,
                'license_key' => $license_key,
                'domain' => $domain,
            ]),
            'timeout' => 10,
        ]);

        echo '<div><h3>Fraud Check</h3>';

        if (is_wp_error($response)) {
            echo '<p style="color:red;">Could not fetch fraud data.</p></div>';
            return;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!$body || !is_array($body)) {
            echo '<p style="color:red;">Invalid response from server.</p></div>';
            return;
        }

        echo '<table style="width:100%; border-collapse:collapse;" border="1">';
        echo '<tr><th>Courier</th><th>Success</th><th>Cancel</th><th>Cancel Ratio (%)</th></tr>';
        foreach ($body as $courier => $data) {
            $success = $data['success'] ?? 0;
            $cancel = $data['cancel'] ?? 0;
            $ratio = $data['cancelRatio'] ?? 0;
            echo "<tr>
                <td>" . esc_html($courier) . "</td>
                <td>" . esc_html($success) . "</td>
                <td>" . esc_html($cancel) . "</td>
                <td>" . esc_html($ratio) . "</td>
            </tr>";
        }
        echo '</table></div>';
    }

    public function add_order_column($columns)
    {
        $new_columns = [];
        $selected_provider = get_option('courier_manager_selected_provider', 'redx');

        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            if ($key === 'order_total') {
                $new_columns['zyncops_fraud_clmn'] = __('Courier Ratio', 'your-text-domain');
            }
        }

        return $new_columns;
    }

    public function render_order_column($column, $post)
    {

        if ('zyncops_fraud_clmn' === $column) {
            $post = $post instanceof WC_Order ? $post : wc_get_order($post);

            $post_id = $post->ID;
            $order_data = $this->prepare_full_order_data($post_id);
            $order_data['key'] = get_option('zyncops_licence_key');
            $json_data = json_encode($order_data);

            echo '<div class="zyncops-courier-ratio"' .
                'data-url="' . BASE_URL . 'fraud-check/' . '"' .
                'data-order="' . esc_html($json_data) . '">
                    
                </div>
            ';

            // echo '
            //     <div class="ratio" style="display: flex; overflow: hidden;">
            //         <div class="bg-green" style="width: ' . $green_width . '%; height: 100%;"></div>
            //         <div class="bg-red" style="width: ' . $red_width . '%; height: 100%;"></div>
            //     </div>
            // ';
            // echo '<div><span>Total:</span> ' . (string) $total . '</div>';
            // echo '<div><span class="text-green">Success:</span> ' . (string) $total_success . '</div>';
            // echo '<div><span class="text-red">Cancelled:</span> ' . (string) $total_cancel . '</div>';

        }
    }

    function get_courier_details($phone, $order_id)
    {
        $license_key = get_option('zyncops_licence_key');
        $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');
        $parsed = parse_url(site_url());
        $domain = $parsed['host'];

        $order_data = $this->prepare_full_order_data($order_id);

        if ($is_licence_valid == 'no') {
            echo '<div><strong>Fraud Check:</strong> Please activate your licence.</div>';
            return false;
        }

        if (!$phone) {
            echo '<div><strong>Fraud Check:</strong> Missing phone number.</div>';
            return false;
        }

        $api_url = BASE_URL . 'fraud-check/'; // Replace with your actual Django URL

        $response = wp_remote_post($api_url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => json_encode([
                'phone' => $phone,
                'license_key' => $license_key,
                'domain' => $domain,
                'order' => $order_data
            ]),
            'timeout' => 10,
        ]);


        if (is_wp_error($response)) {
            echo '<p style="color:red;">Could not fetch fraud data.</p>';
            return false;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!$body || !is_array($body)) {
            echo '<p style="color:red;">Invalid response from server.</p>';
            return false;
        }

        return $body;
    }

    function get_courier_data_by_phone($phone)
    {
        global $wpdb;

        $table_name = $wpdb->prefix . 'zyncops_courier_data';

        $result = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE phone = %s LIMIT 1", $phone),
            ARRAY_A
        );

        return $result;
    }

    function update_or_create_courier_data_by_phone($phone, $data = [])
    {
        global $wpdb;

        $table_name = $wpdb->prefix . 'zyncops_courier_data';

        if (empty($phone) || empty($data) || !is_array($data)) {
            return false;
        }

        // Check if the record exists
        $existing = $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE phone = %s", $phone)
        );

        if ($existing > 0) {
            // Update the existing row
            $result = $wpdb->update(
                $table_name,
                $data,
                ['phone' => $phone],
                null,
                ['%s']
            );
        } else {
            // Insert new row
            $data['phone'] = $phone;
            $result = $wpdb->insert(
                $table_name,
                $data
            );
        }

        return $result !== false;
    }

    function prepare_full_order_data($order_id)
    {
        $order = wc_get_order($order_id);
        if (!$order) {
            return null;
        }

        $order_data = $order->get_data(); // basic order fields

        // Convert datetime objects to strings
        foreach ($order_data as $key => $value) {
            if ($value instanceof WC_DateTime) {
                $order_data[$key] = $value->date('Y-m-d H:i:s');
            }
        }

        // Order items
        $items = [];
        foreach ($order->get_items() as $item_id => $item) {
            $product = $item->get_product();
            $items[] = [
                'id' => $item_id,
                'name' => $item->get_name(),
                'product_id' => $item->get_product_id(),
                'variation_id' => $item->get_variation_id(),
                'quantity' => $item->get_quantity(),
                'subtotal' => $item->get_subtotal(),
                'total' => $item->get_total(),
                'tax' => $item->get_total_tax(),
                'sku' => $product ? $product->get_sku() : '',
            ];
        }

        // Shipping methods
        $shipping = [];
        foreach ($order->get_shipping_methods() as $shipping_item) {
            $shipping[] = $shipping_item->get_data();
        }

        // Fee lines
        $fees = [];
        foreach ($order->get_fees() as $fee_item) {
            $fees[] = $fee_item->get_data();
        }

        // Coupons
        $coupons = [];
        foreach ($order->get_coupon_codes() as $coupon_code) {
            $coupons[] = $coupon_code;
        }

        // Final structure
        $order_data['items'] = $items;
        $order_data['shipping'] = $shipping;
        $order_data['fees'] = $fees;
        $order_data['coupons'] = $coupons;

        return $order_data;
    }

}