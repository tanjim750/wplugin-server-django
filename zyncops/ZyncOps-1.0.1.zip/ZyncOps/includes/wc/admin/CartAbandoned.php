<?php

class CartAbandoned
{
    private $base_url = 'https://d6c8-202-134-14-141.ngrok-free.app/';
    public function init_action()
    {
        $is_enabled = get_option('cart_abandoned_enabled', 'yes');
        $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');

        if ($is_enabled == 'no' || $is_licence_valid == 'no') {
            return;
        }

        add_action('woocommerce_cart_updated', [$this, 'item_added_to_cart']);
        add_action('woocommerce_before_checkout_form', [$this, 'landed_on_checkout_page']);
        add_action('woocommerce_checkout_update_order_review', [$this, 'update_user_info']);
        add_action('woocommerce_thankyou', [$this, 'set_as_converted_or_delete']);
        // add_action('admin_menu', [$this, 'add_wc_cart_abandoned_submenu']);

    }


    public function get_current_user_info()
    {
        $user_id = get_current_user_id();
        $session_id = WC()->session->get_customer_id(); // works for both guests and logged-in users

        if ($user_id) {
            // Logged-in user
            $user = get_userdata($user_id);
            $first_name = $user->first_name;
            $last_name = $user->last_name;
            $email = $user->user_email;
            $phone = get_user_meta($user_id, 'billing_phone', true);

            // Get address components
            $address_parts = [
                get_user_meta($user_id, 'billing_address_1', true),
                get_user_meta($user_id, 'billing_address_2', true),
                get_user_meta($user_id, 'billing_city', true),
                get_user_meta($user_id, 'billing_state', true),
                get_user_meta($user_id, 'billing_postcode', true),
                get_user_meta($user_id, 'billing_country', true),
            ];
        } else {
            // Guest user
            $checkout = WC()->checkout();
            $first_name = $checkout->get_value('billing_first_name');
            $last_name = $checkout->get_value('billing_last_name');
            $email = $checkout->get_value('billing_email');
            $phone = $checkout->get_value('billing_phone');

            // Get address components
            $address_parts = [
                $checkout->get_value('billing_address_1'),
                $checkout->get_value('billing_address_2'),
                $checkout->get_value('billing_city'),
                $checkout->get_value('billing_state'),
                $checkout->get_value('billing_postcode'),
                $checkout->get_value('billing_country'),
            ];
        }

        // Build the full address
        $address = implode(', ', array_filter($address_parts));

        return [
            'identifier' => $user_id ? 'user_' . $user_id : 'session_' . $session_id,
            'name' => trim($first_name . ' ' . $last_name),
            'email' => $email,
            'phone' => $phone,
            'address' => $address,
        ];
    }


    public function get_completion_ratio_from_checkout_fields()
    {
        $checkout = WC()->checkout();
        $ratio = 0;

        if ($checkout->get_value('billing_first_name'))
            $ratio += 10;
        if ($checkout->get_value('billing_email'))
            $ratio += 10;
        if ($checkout->get_value('billing_address_1'))
            $ratio += 10;
        if ($checkout->get_value('billing_phone'))
            $ratio += 20;

        return $ratio;
    }


    public function item_added_to_cart()
    {
        if (WC()->cart->is_empty()) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'zyncops_abandoned_cart';

        $user_id = get_current_user_id();
        $session_id = WC()->session->get_customer_id(); // works for both logged-in & guests
        $identifier = $user_id ? 'user_' . $user_id : 'session_' . $session_id;

        // Prepare cart items
        $items = [];
        foreach (WC()->cart->get_cart() as $cart_item) {
            $product = $cart_item['data'];
            $items[] = [
                'id' => $product->get_id(),
                'name' => $product->get_name(),
                'quantity' => $cart_item['quantity'],
                'price' => $product->get_price(),
            ];
        }

        $items_json = json_encode($items);

        // Check for an existing abandoned cart
        $existing_cart_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE user_identifier = %s AND action = 'abandoned' ORDER BY created_at DESC LIMIT 1",
            $identifier
        ));

        $user_info = $this->get_current_user_info(); // Get user/session info

        if ($existing_cart_id) {
            // Update the existing abandoned cart
            $wpdb->update(
                $table,
                [
                    'items' => $items_json,
                ],
                ['id' => $existing_cart_id]
            );
        } else {
            // Insert new abandoned cart
            $wpdb->insert(
                $table,
                [
                    'user_identifier' => $user_info['identifier'],
                    'items' => $items_json,
                    'name' => $user_info['name'],
                    'email' => $user_info['email'],
                    'phone' => $user_info['phone'],
                    'completion_ratio' => 10,
                    'action' => 'abandoned',
                    'created_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql'),
                ]
            );
        }
    }

    public function landed_on_checkout_page()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'zyncops_abandoned_cart';

        $user_info = $this->get_current_user_info();
        $identifier = $user_info['identifier'];

        // Get the latest abandoned cart ID
        $cart_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE user_identifier = %s AND action = 'abandoned' ORDER BY created_at DESC LIMIT 1",
            $identifier
        ));

        if ($cart_id) {
            // Get current completion_ratio
            $current_ratio = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT completion_ratio FROM $table WHERE id = %d",
                $cart_id
            ));

            // Desired new ratio
            $new_ratio = 30 + $this->get_completion_ratio_from_checkout_fields();

            // Only update if value is different
            if ($current_ratio !== $new_ratio) {
                $updated = $wpdb->update(
                    $table,
                    [
                        'completion_ratio' => $new_ratio,
                        'updated_at' => current_time('mysql'),
                    ],
                    ['id' => $cart_id]
                );

                if ($updated === false) {
                    error_log('Failed to update completion_ratio: ' . $wpdb->last_error);
                }
            }
        }
    }



    public function update_user_info($post_data)
    {

        // Parse the incoming form data
        parse_str($post_data, $data);

        global $wpdb;
        $table = $wpdb->prefix . 'zyncops_abandoned_cart';

        // Identify user/session
        $user_info = $this->get_current_user_info();
        $identifier = $user_info['identifier'];

        // Sanitize input fields
        $name = sanitize_text_field($data['billing_first_name'] ?? '');
        $email = sanitize_email($data['billing_email'] ?? '');
        $phone = sanitize_text_field($data['billing_phone'] ?? '');
        $address = sanitize_text_field($data['billing_address_1'] ?? '');

        // Dynamically calculate completion ratio
        $completion = 10 + 20; // base: added to cart + landed on checkout
        if (!empty($name))
            $completion += 10;
        if (!empty($email))
            $completion += 10;
        if (!empty($phone))
            $completion += 20;
        if (!empty($address))
            $completion += 10;

        // Get the latest cart for this identifier
        $cart_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE user_identifier = %s AND action = 'abandoned' ORDER BY created_at DESC LIMIT 1",
            $identifier
        ));

        if ($cart_id) {
            $result = $wpdb->update(
                $table,
                [
                    'name' => $name,
                    'email' => $email,
                    'phone' => $phone,
                    'address' => $address,
                    'completion_ratio' => $completion,
                    'updated_at' => current_time('mysql'),
                ],
                ['id' => $cart_id]
            );

            if ($result === false) {
                error_log('Abandoned cart update failed: ' . $wpdb->last_error);
            }
        }
    }



    public function set_as_converted_or_delete($order_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'zyncops_abandoned_cart';

        $order = wc_get_order($order_id);
        if (!$order)
            return;

        // Get order-related user info
        $email = $order->get_billing_email();
        $name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
        $phone = $order->get_billing_phone();

        // Get user/session identifier
        $user_info = $this->get_current_user_info();
        $identifier = $user_info['identifier'];

        // Get the latest abandoned cart for this user/session
        $cart = $wpdb->get_row($wpdb->prepare(
            "SELECT id, created_at FROM $table WHERE user_identifier = %s AND action = 'abandoned' ORDER BY created_at DESC LIMIT 1",
            $identifier
        ));

        if ($cart) {
            $created_time = strtotime($cart->created_at);
            $current_time = current_time('timestamp');
            $diff_minutes = ($current_time - $created_time) / 60;
            $time_limit_minutes = intval(get_option('cart_abandoned_time', 30)); // default 30 min

            if ($diff_minutes > $time_limit_minutes) {
                // Update as converted with user info
                $wpdb->update(
                    $table,
                    [
                        'completion_ratio' => 100,
                        'action' => 'converted',
                        'email' => $email,
                        'name' => $name,
                        'phone' => $phone,
                        'updated_at' => current_time('mysql'),
                    ],
                    ['id' => $cart->id]
                );
            } else {
                $wpdb->delete($table, ['id' => $cart->id]);
            }
        }
    }



}