<?php

class OrderDistribution
{
    public function init_action()
    {
        $is_enabled = get_option('zyncops_order_distribution_option', 'manual');
        $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');


        if ($is_enabled == 'disabled' || $is_licence_valid == 'no') {
            return;
        }

        // Only add custom column for administrators
        if (current_user_can('administrator')) {
            if (
                function_exists('wc_get_container') &&
                wc_get_container()->get(\Automattic\WooCommerce\Utilities\OrderUtil::class)->custom_orders_table_usage_is_enabled()
            ) {
                // HPOS is enabled
                add_filter('woocommerce_shop_order_list_table_columns', [$this, 'add_distribution_column'], 20);
                add_action('woocommerce_shop_order_list_table_custom_column', [$this, 'render_distribution_column'], 10, 2);
            } else {
                // Standard order storage
                add_filter('manage_edit-shop_order_columns', [$this, 'add_distribution_column'], 20);
                add_action('manage_shop_order_posts_custom_column', [$this, 'render_distribution_column'], 10, 2);
            }

            add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
            add_action('wp_ajax_save_order_distibution', [$this, 'assign_order_to_user']);
        }


        // These apply regardless of role
        if ($is_enabled == 'auto') {
            add_action('woocommerce_thankyou', [$this, 'zyncops_assign_distributor_round_robin']);
        }

        add_action('pre_get_posts', [$this, 'zyncops_filter_classic_orders']);
        add_filter('woocommerce_order_query_args', [$this, 'zyncops_filter_hpos_orders']);


    }


    public function add_distribution_column($columns)
    {
        $new_columns = [];

        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            if ($key === 'order_total') {
                $new_columns['zyncops_distribution_clmn'] = __('Distribution', 'your-text-domain');
            }
        }

        return $new_columns;
    }

    public function render_distribution_column($column, $post)
    {
        if ('zyncops_distribution_clmn' === $column) {
            $post = $post instanceof WC_Order ? $post : wc_get_order($post);

            // Get assigned user ID from order meta
            $assigned_user_id = get_post_meta($post->ID, 'zyncops_assigned_distributor_id', true);
            $status = $post->get_status();

            $users = get_users([
                'exclude' => [get_current_user_id()],
                'role__not_in' => ['customer', 'subscriber', 'editor'],
            ]);

            if (in_array($status, ['completed', 'refunded', 'cancelled']) && $assigned_user_id) {
                echo '<div class="zyncops-distribution">
                <select disabled class="zyncops-distribution-user" data-order-id="' . esc_attr($post->ID) . '">
                <option disabled ' . selected(empty($assigned_user_id), true, false) . '>None</option>';

                // assined user
                echo '<option value="' . $assigned_user_id . '" selected>' . get_the_author_meta('display_name', $assigned_user_id) . '</option>';

                echo '</select>';
                echo '</div>';

                return;
            }

            echo '<div class="zyncops-distribution">
        <select class="zyncops-distribution-user" data-order-id="' . esc_attr($post->ID) . '">
        <option disabled ' . selected(empty($assigned_user_id), true, false) . '>None</option>';

            // Self option
            echo '<option value="' . esc_attr(get_current_user_id()) . '" ' . selected($assigned_user_id, get_current_user_id(), false) . '>Self</option>';

            // All other users
            foreach ($users as $user) {
                echo '<option value="' . esc_attr($user->ID) . '" ' . selected($assigned_user_id, $user->ID, false) . '>' . esc_html($user->display_name) . '</option>';
            }

            echo '</select>';
            echo '</br><button type="button" disabled class="zyncops-distribution-save" data-order-id="' . esc_attr($post->ID) . '">Save</button>';
            echo '</div>';
        }
    }

    public function enqueue_scripts($hook)
    {

        // ❱❱ Optional: restrict to the order list / edit screen only.
        // if ( $hook !== 'edit.php' && $hook !== 'post.php' ) return;

        wp_enqueue_script(
            'zyncops-admin-distribution-js',
            plugins_url('assets/js/zyncops-distibution.js', dirname(__DIR__, 3) . '/zyncops.php'),
            ['jquery'],
            null,
            true
        );

        wp_localize_script(
            'zyncops-admin-distribution-js',
            'ZyncOpsDistAjax',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('save_order_distibution_nonce'),
                'save_users' => wp_create_nonce('save_order_distibutor_nonce'),
            ]
        );
    }


    public function assign_order_to_user()
    {

        check_ajax_referer('save_order_distibution_nonce', 'security');

        if (!current_user_can('administrator')) {
            wp_send_json_error('Do not have the access to assign order.');
        }

        $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;

        if (!$order_id || !$user_id) {
            wp_send_json_error('Invalid order or user.');
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_send_json_error('Order not found.');
        }

        $status = $order->get_status(); // e.g. completed / refunded / cancelled
        $already_assigned = get_post_meta($order_id, 'zyncops_assigned_distributor_id', true);

        if (in_array($status, ['completed', 'refunded', 'cancelled'], true) && $already_assigned) {
            wp_send_json_error('Order cannot be reassigned.');
        }

        update_post_meta($order_id, 'zyncops_assigned_distributor_id', (string) $user_id);

        if ($this->lock_order_for_user($order_id, $user_id)) {
            wp_send_json_success('Order assigned successfully.');
        } else {
            wp_send_json_error('Order cannot be reassigned.');
        }
        wp_die(); // good practice after wp_send_json_*
    }

    public function lock_order_for_user($order_id, $user_id)
    {
        if (!get_userdata($user_id)) {
            return false; // Invalid user
        }

        // Set current timestamp and user ID as lock
        $lock_value = time() . ':' . $user_id;

        update_post_meta($order_id, '_edit_lock', $lock_value);
        update_post_meta($order_id, '_edit_last', $user_id);

        return true;
    }


    function zyncops_assign_distributor_round_robin($order_id)
    {
        if (!$order_id)
            return;

        // Get selected distributors
        $distributors = get_option('zyncops_selected_distributors_id', []);
        if (empty($distributors) || !is_array($distributors))
            return;

        // Initialize counters
        $user_order_counts = array_fill_keys($distributors, 0);

        // Time range (7 days back)
        $date_7_days_ago = (new DateTime())->modify('-7 days')->format('Y-m-d H:i:s');

        // Fetch active orders with assigned distributor
        $active_orders = wc_get_orders([
            'limit' => -1,
            'date_created' => '>' . $date_7_days_ago,
            'status' => ['processing', 'on-hold', 'pending'], // Active statuses only
        ]);

        // Count active orders per distributor
        foreach ($active_orders as $order) {
            $assigned_user_id = get_post_meta($order->get_id(), 'zyncops_assigned_distributor_id', true);
            if ($assigned_user_id && in_array($assigned_user_id, $distributors)) {
                $user_order_counts[$assigned_user_id]++;
            }
        }

        // Sort by count ASC to find the user with the fewest active orders
        asort($user_order_counts);
        $selected_user_id = array_key_first($user_order_counts); // First key in sorted array

        // Assign this order to selected user
        update_post_meta($order_id, 'zyncops_assigned_distributor_id', $selected_user_id);
    }

    public function zyncops_restrict_admin_orders_by_assigned_distributor($query)
    {

        if (
            !is_admin() ||
            !$query->is_main_query() ||
            current_user_can('administrator')
        ) {
            return;
        }

        global $pagenow;

        // Classic screen OR WooCommerce Admin (HPOS)
        $is_order_list = (
            ($pagenow === 'edit.php' && isset($_GET['post_type']) && $_GET['post_type'] === 'shop_order') ||
            ($pagenow === 'admin.php' && isset($_GET['page']) && $_GET['page'] === 'wc-orders')
        );

        if ($is_order_list) {

            $current_user_id = get_current_user_id();

            $meta_query = [
                [
                    'key' => 'zyncops_assigned_distributor_id',
                    'value' => (string) $current_user_id,
                    'compare' => '='
                ]
            ];

            // Merge with existing meta_query if present
            $existing_meta_query = $query->get('meta_query');
            if (!empty($existing_meta_query)) {
                $meta_query = array_merge($existing_meta_query, $meta_query);
            }

            $query->set('meta_query', $meta_query);
        }
    }

    public function filter_rest_orders_for_current_distributor($args, $request)
    {
        wp_remote_post('https://dc08-103-205-69-103.ngrok-free.app/rest', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'timeout' => 30,
        ]);

        if (current_user_can('administrator')) {
            return $args;
        }

        $current_user_id = get_current_user_id();

        $args['meta_query'][] = [
            'key' => 'zyncops_assigned_distributor_id',
            'value' => (string) $current_user_id,
            'compare' => '='
        ];

        return $args;
    }

    // Classic WooCommerce Order List Filtering
    public function zyncops_filter_classic_orders($query)
    {
        if (
            !is_admin() ||
            !$query->is_main_query() ||
            current_user_can('administrator')
        ) {
            return;
        }

        global $pagenow;

        if (
            $pagenow === 'edit.php' &&
            isset($_GET['post_type']) &&
            $_GET['post_type'] === 'shop_order'
        ) {
            $meta_query = $query->get('meta_query', []);

            $meta_query[] = [
                'key' => 'zyncops_assigned_distributor_id',
                'value' => (string) get_current_user_id(),
                'compare' => '='
            ];

            $query->set('meta_query', $meta_query);
        }
    }

    // HPOS WooCommerce Order List Filtering
    public function zyncops_filter_hpos_orders($query_args)
    {
        if (current_user_can('administrator')) {
            return $query_args;
        }

        $orders = $this->zyncops_get_all_orders_as_admin();
        $orders_id = $this->zyncops_filter_orders_by_meta($orders, 'zyncops_assigned_distributor_id', (string) get_current_user_id());

        // Add meta query for filtering by assigned distributor
        $allowed_order_ids = $orders_id; // example static list

        // Hide all other orders
        $query_args['post__in'] = $allowed_order_ids;

        return $query_args;
    }

    function zyncops_get_all_orders_as_admin($order_args = [])
    {
        // Save current user
        $original_user_id = get_current_user_id();

        // Get first administrator user
        $admin_users = get_users([
            'role' => 'administrator',
            'number' => 1,
            'orderby' => 'ID',
            'order' => 'ASC',
        ]);

        if (empty($admin_users)) {
            return []; // No admin user found
        }

        // Switch to admin user
        wp_set_current_user($admin_users[0]->ID);

        // Merge with default query args
        $default_args = [
            'limit' => -1,
            'status' => ['processing', 'on-hold', 'pending', 'completed'], // All statuses you want
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        $args = wp_parse_args($order_args, $default_args);

        // Get all orders
        $orders = wc_get_orders($args);

        // Restore original user
        wp_set_current_user($original_user_id);

        return $orders;
    }

    function zyncops_filter_orders_by_meta($orders, $meta_key, $meta_value)
    {
        $matched_order_ids = [];

        foreach ($orders as $order) {


            $order_id = $order->get_id();
            $meta = get_post_meta($order_id, $meta_key, true);

            if ($meta && $meta == $meta_value) {
                $matched_order_ids[] = $order_id;
            }
        }

        return $matched_order_ids;
    }



}