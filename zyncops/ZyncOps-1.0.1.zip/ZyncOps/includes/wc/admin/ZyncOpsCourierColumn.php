<?php

class ZyncOpsCourierColumn
{
    private $base_url = 'https://2588-103-205-69-99.ngrok-free.app/';
    public function addColumn()
    {
        $is_enabled = get_option('zyncops_courier_enabled', 'no');
        $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');


        if ($is_enabled == 'no' || $is_licence_valid == 'no') {
            return;
        }

        if (function_exists('wc_get_container') && wc_get_container()->get(\Automattic\WooCommerce\Utilities\OrderUtil::class)->custom_orders_table_usage_is_enabled()) {
            // HPOS is enabled
            add_filter('woocommerce_shop_order_list_table_columns', [$this, 'add_order_column'], 20);
            add_action('woocommerce_shop_order_list_table_custom_column', [$this, 'render_order_column'], 10, 2);
        } else {
            // Standard order storage
            add_filter('manage_edit-shop_order_columns', [$this, 'add_order_column'], 20);
            add_action('manage_shop_order_posts_custom_column', [$this, 'render_order_column'], 10, 2);
        }

        // Add metabox
        add_action('add_meta_boxes', [$this, 'add_tracking_metabox']);

        // Save for both HPOS and legacy
        add_action('save_post_shop_order', [$this, 'save_tracking_meta'], 10, 2);
        add_action('woocommerce_process_shop_order_meta', [$this, 'save_tracking_meta']);
        add_action('woocommerce_admin_process_custom_order', [$this, 'save_tracking_meta']);


        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_send_order_to_courier', [$this, 'ajax_send_order_to_courier']);
        add_action('wp_ajax_track_parcel', [$this, 'ajax_track_parcel']);

    }

    public function enqueue_scripts($hook)
    {
        wp_enqueue_script('zyncops-admin-courier-js', plugins_url('assets/js/zyncops-courier.js', dirname(__DIR__, 3) . '/zyncops.php'), ['jquery'], null, true);
        wp_localize_script('zyncops-admin-courier-js', 'ZyncOpsAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('send_order_to_courier_nonce'),
            'track' => wp_create_nonce('track_parcel_nonce')
        ]);
    }

    public function ajax_send_order_to_courier()
    {

        check_ajax_referer('send_order_to_courier_nonce', 'nonce');


        $test_enabled = get_option('courier_test_enabled', 'no');

        $order_id = intval($_POST['order_id']);

        if (!$order_id) {
            wp_send_json_error('Invalid order ID');
        }

        $license_key = get_option('zyncops_licence_key');
        $parsed = parse_url(site_url());
        $domain = $parsed['host']; // This gives you just "example.com"
        $platform = get_option('courier_manager_selected_provider'); // e.g., 'pathao'

        $credentials = [];

        if ($platform == 'redx') {
            $credentials['api_key'] = get_option('redx_api_key', '');
        } else if ($platform == 'steadfast') {
            $credentials['api_key'] = get_option('courier_manager_steadfast_api_key', '');
            $credentials['secret_key'] = get_option('courier_manager_steadfast_secret_key', '');
        } else if ($platform == 'pathao') {
            $credentials['client_id'] = get_option('courier_manager_pathao_client_id', '');
            $credentials['client_secret'] = get_option('courier_manager_pathao_client_secret', '');
            $credentials['username'] = get_option('courier_manager_pathao_username', '');
            $credentials['password'] = get_option('courier_manager_pathao_password', '');
        }

        $order_data = $this->prepare_full_order_data($order_id);

        $payload = [
            'license_key' => $license_key,
            'domain' => $domain,
            'platform' => $platform,
            'credentials' => $credentials,
            'data' => $order_data,
            'test_mode' => $test_enabled === 'yes'
        ];

        $response = wp_remote_post(BASE_URL . 'create-parcel/', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($payload),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            wp_send_json_error('Failed to send order: ' . $response->get_error_message());
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['success']) && $data['success']) {
            $tracking_id = $data['tracking_id'] ?? null;
            if ($tracking_id) {
                update_post_meta($order_id, 'zyncops_tracking_id', $tracking_id);
                update_post_meta($order_id, 'courier_tracking_platform', $platform);
            }
            wp_send_json_success($data);
        } else {
            wp_send_json_error(isset($data['error']) ? $data['error'] : 'Unknown error');
        }

    }

    public function ajax_track_parcel()
    {
        check_ajax_referer('track_parcel_nonce', 'nonce');

        $order_id = intval($_POST['order_id']);
        if (!$order_id) {
            wp_send_json_error('Invalid order ID');
        }

        $order_id = intval($_POST['order_id']);
        if (!$order_id) {
            wp_send_json_error('Invalid order ID');
        }

        $response = $this->track_parcel($order_id);

        if (is_wp_error($response)) {
            wp_send_json_error('Failed to track order: ' . $response->get_error_message());
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['success']) && $data['success']) {
            wp_send_json_success($data);
        } else {
            wp_send_json_error(isset($data['error']) ? $data['error'] : 'Unknown error');
        }

    }

    function prepare_full_order_data($order_id)
    {
        $order = wc_get_order($order_id);
        if (!$order) {
            return null;
        }

        $order_data = $order->get_data(); // basic order fields

        // Convert datetime objects to strings
        foreach ($order_data as $key => $value) {
            if ($value instanceof WC_DateTime) {
                $order_data[$key] = $value->date('Y-m-d H:i:s');
            }
        }

        // Order items
        $items = [];
        foreach ($order->get_items() as $item_id => $item) {
            $product = $item->get_product();
            $items[] = [
                'id' => $item_id,
                'name' => $item->get_name(),
                'product_id' => $item->get_product_id(),
                'variation_id' => $item->get_variation_id(),
                'quantity' => $item->get_quantity(),
                'subtotal' => $item->get_subtotal(),
                'total' => $item->get_total(),
                'tax' => $item->get_total_tax(),
                'sku' => $product ? $product->get_sku() : '',
            ];
        }

        // Shipping methods
        $shipping = [];
        foreach ($order->get_shipping_methods() as $shipping_item) {
            $shipping[] = $shipping_item->get_data();
        }

        // Fee lines
        $fees = [];
        foreach ($order->get_fees() as $fee_item) {
            $fees[] = $fee_item->get_data();
        }

        // Coupons
        $coupons = [];
        foreach ($order->get_coupon_codes() as $coupon_code) {
            $coupons[] = $coupon_code;
        }

        // Final structure
        $order_data['items'] = $items;
        $order_data['shipping'] = $shipping;
        $order_data['fees'] = $fees;
        $order_data['coupons'] = $coupons;

        return $order_data;
    }

    public function track_parcel($order_id)
    {

        $license_key = get_option('zyncops_licence_key');
        $parsed = parse_url(site_url());
        $domain = $parsed['host']; // This gives you just "example.com"
        $platform = get_post_meta($order_id, 'courier_tracking_platform', true); // e.g., 'pathao'

        $credentials = [];

        if ($platform == 'redx') {
            $credentials['api_key'] = get_option('redx_api_key', '');
        } else if ($platform == 'steadfast') {
            $credentials['api_key'] = get_option('courier_manager_steadfast_api_key', '');
            $credentials['secret_key'] = get_option('courier_manager_steadfast_secret_key', '');
        } else if ($platform == 'pathao') {
            $credentials['client_id'] = get_option('courier_manager_pathao_client_id', '');
            $credentials['client_secret'] = get_option('courier_manager_pathao_client_secret', '');
            $credentials['username'] = get_option('courier_manager_pathao_username', '');
            $credentials['password'] = get_option('courier_manager_pathao_password', '');
        }

        $tracking_id = get_post_meta($order_id, 'zyncops_tracking_id', true);

        $payload = [
            'license_key' => $license_key,
            'domain' => $domain,
            'platform' => $platform,
            'credentials' => $credentials,
            'tracking_id' => $tracking_id,
            'test_mode' => true
        ];

        $response = wp_remote_post(BASE_URL . 'track-parcel/', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($payload),
            'timeout' => 30,
        ]);

        return $response;
    }

    public function add_order_column($columns)
    {
        $new_columns = [];
        $selected_provider = get_option('courier_manager_selected_provider', 'redx');

        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            if ($key === 'order_total') {
                $new_columns['zyncops_woo_clmn'] = __('Send to ' . $selected_provider, 'your-text-domain');
            }
        }

        return $new_columns;
    }

    public function render_order_column($column, $post)
    {

        if ('zyncops_woo_clmn' === $column) {
            $post = $post instanceof WC_Order ? $post : wc_get_order($post);

            $post_id = $post->ID;
            $tracking = get_post_meta($post_id, 'zyncops_tracking_id', true);
            $selected_provider = get_option('courier_manager_selected_provider', 'redx');
            $order = wc_get_order($post_id);


            if ($tracking) {
                if ($order) {
                    echo '<button type="button" class="button zyncops-track-parcel" data-order-id="' . esc_attr($post_id) . '">Track Parcel</button>';
                } else {
                    echo '<em>Order ID not found</em>';
                }

            } else {
                if (!$tracking && $selected_provider && $order && (!$order->has_status(['completed', 'refunded', 'cancelled', 'failed']))) {
                    echo '<button type="button" class="button zyncops-send-to-courier" data-order-id="' . esc_attr($post_id) . '">Send</button>';
                }
            }
        }
    }

    public function add_tracking_metabox()
    {
        // Works for both HPOS and legacy
        add_meta_box(
            'zyncops_tracking_box',
            'Courier Tracking ID',
            [$this, 'render_tracking_metabox'],
            null,
            'side',
            'default'
        );
    }


    public function render_tracking_metabox($post)
    {
        // Works for both HPOS and legacy
        $order_id = $post->ID;
        $tracking = get_post_meta($order_id, 'zyncops_tracking_id', true);
        $platform = get_post_meta($order_id, 'courier_tracking_platform', true);

        echo '<label for="zyncops_tracking_id">Tracking ID</label>';
        echo '<input type="text" name="zyncops_tracking_id" value="' . esc_attr($tracking) . '" style="width:100%">';

        echo '<br><br>';
        echo '<label for="courier_tracking_platform">Courier Platform</label>';
        echo '<select name="courier_tracking_platform" style="width:100%">';
        echo '<option value="redx"' . selected($platform, 'redx', false) . '>Redx</option>';
        echo '<option value="steadfast"' . selected($platform, 'steadfast', false) . '>Steadfast</option>';
        echo '<option value="pathao"' . selected($platform, 'pathao', false) . '>Pathao</option>';
        echo '</select>';
    }


    public function save_tracking_meta($order_id)
    {
        if (isset($_POST['zyncops_tracking_id'])) {
            update_post_meta($order_id, 'zyncops_tracking_id', sanitize_text_field($_POST['zyncops_tracking_id']));
        }

        if (isset($_POST['courier_tracking_platform'])) {
            update_post_meta($order_id, 'courier_tracking_platform', sanitize_text_field($_POST['courier_tracking_platform']));
        }
    }

}