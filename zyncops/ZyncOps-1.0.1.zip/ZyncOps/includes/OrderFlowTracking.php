<?php

class OrderFlowTracking
{
    private $base_url = 'https://d6c8-202-134-14-141.ngrok-free.app/';

    public function init_action()
    {
        $is_enabled = get_option('zyncops_order_flow_enabled', 'no');
        $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');

        if ($is_enabled == 'no' || $is_licence_valid == 'no') {
            return;
        }


        // Save fbp and fbc at checkout
        add_action('woocommerce_checkout_create_order', [$this, 'save_fb_pixel_data_to_order'], 10, 2);

        // Trigger on order status change
        add_action('woocommerce_order_status_changed', [$this, 'track_order_status_change'], 10, 3);

        // Enqueue JS on checkout page
        add_action('wp_enqueue_scripts', [$this, 'enqueue_checkout_scripts']);

    }

    public function enqueue_checkout_scripts()
    {
        if (is_checkout()) {
            wp_enqueue_script('zyncops-fb-cookie-capture', plugin_dir_url(__FILE__) . 'assets/js/fb-cookie-capture.js', [], '1.0', true);
        }
    }

    public function save_fb_pixel_data_to_order($order, $data)
    {
        if (isset($_POST['fbp'])) {
            $order->update_meta_data('fbp', sanitize_text_field($_POST['fbp']));
        }
        if (isset($_POST['fbc'])) {
            $order->update_meta_data('fbc', sanitize_text_field($_POST['fbc']));
        }
    }

    function prepare_full_order_data_for_fb_pixel($order_id)
    {
        $order = wc_get_order($order_id);
        if (!$order)
            return null;

        $items = [];
        foreach ($order->get_items() as $item_id => $item) {
            $product = $item->get_product();
            $items[] = [
                'id' => $product ? $product->get_id() : null,
                'quantity' => $item->get_quantity(),
                'item_price' => $item->get_total() / max(1, $item->get_quantity()), // fallback to per item
            ];
        }

        $customer = [
            'email' => $order->get_billing_email(),
            'phone' => $order->get_billing_phone(),
            'ip_address' => $order->get_customer_ip_address(),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'first_name' => $order->get_billing_first_name(),
            'last_name' => $order->get_billing_last_name(),
            'city' => $order->get_billing_city(),
            'state' => $order->get_billing_state(),
            'zip' => $order->get_billing_postcode(),
            'country' => $order->get_billing_country(),
            'fbp' => $order->get_meta('fbp'),
            'fbc' => $order->get_meta('fbc'),
        ];

        $data = [
            'order_id' => $order->get_id(),
            'currency' => $order->get_currency(),
            'value' => $order->get_total(),
            'contents' => $items,
            'content_type' => 'product',
            'customer' => $customer,
            'event_time' => time(),
        ];

        return $data;
    }

    public function track_order_status_change($order_id, $old_status, $new_status)
    {
        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            error_log("Invalid order ID: $order_id");
            return;
        }

        $order_number = $order->get_order_number();
        $license_key = get_option('zyncops_licence_key');
        $parsed = parse_url(site_url());
        $domain = isset($parsed['host']) ? $parsed['host'] : '';

        $pixel_id = get_option('zyncops_facebook_pixel_id') ?: null;
        $pixel_token = get_option('zyncops_facebook_pixel_token') ?: null;
        $pixel_test_code = get_option('zyncops_facebook_pixel_test_code') ?: null;

        $payload = [
            'license_key' => $license_key,
            'domain' => $domain,
            'url' => site_url(),
            'pixel_id' => $pixel_id,
            'access_token' => $pixel_token,
            'test_event' => $pixel_test_code,
            'current_status' => $new_status,
            'old_status' => $old_status,
            'details' => $this->prepare_full_order_data_for_fb_pixel($order_id)
        ];

        $response = wp_remote_post(BASE_URL . 'send-event/', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($payload),
            'timeout' => 20,
        ]);

        if (is_wp_error($response)) {
            error_log('Error sending FB Pixel event: ' . $response->get_error_message());
        } else {
            $body = wp_remote_retrieve_body($response);
            error_log('FB Event Response: ' . $body);
        }
    }
}