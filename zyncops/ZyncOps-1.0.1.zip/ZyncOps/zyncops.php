<?php
/**
 * Plugin Name: ZyncOps
 * Description: ZyncOps is a comprehensive WooCommerce extension that helps you automate courier delivery, recover lost sales, and identify suspicious activity. Designed for Bangladeshi e-commerce businesses, the plugin integrates with leading courier services like Pathao, RedX, and Steadfast, while also offering abandoned cart tracking and fraud detection tools — all from one unified admin dashboard.
 * Version: 1.0.1
 * Author: Trizync Solution
 */

if (!defined('ABSPATH')) {
    exit;
}

define('BASE_URL', 'https://zyncops.triizync.com/');


// Import the class file
require_once plugin_dir_path(__FILE__) . 'includes/settings/MenuSettings.php';
require_once plugin_dir_path(__FILE__) . 'includes/wc/admin/ZyncOpsCourierColumn.php';
require_once plugin_dir_path(__FILE__) . 'includes/wc/customer/OrderLimit.php';
require_once plugin_dir_path(__FILE__) . 'includes/OrderFlowTracking.php';
require_once plugin_dir_path(__FILE__) . 'includes/wc/admin/CartAbandoned.php';
require_once plugin_dir_path(__FILE__) . 'includes/wc/admin/SaleReport.php';
require_once plugin_dir_path(__FILE__) . 'includes/settings/OrderDistMenu.php';
require_once plugin_dir_path(__FILE__) . 'includes/wc/admin/OrderDistribution.php';
require_once plugin_dir_path(__FILE__) . 'includes/settings/CartAbandonedMenu.php';
require_once plugin_dir_path(__FILE__) . 'includes/wc/admin/FraudCheck.php';
require_once plugin_dir_path(__FILE__) . 'includes/wc/customer/OrderTracking.php';
require_once plugin_dir_path(__FILE__) . 'includes/settings/OrderRestrictionMenu.php';

class ZyncOps
{
    private $base_url = 'https://d6c8-202-134-14-141.ngrok-free.app/';
    public function __construct()
    {
        $is_enabled = get_option('zyncops_enabled', 'yes');
        $is_licence_valid = get_option('zyncops_licence_key_valid', 'no');

        // enqueue zyncops style
        add_action('admin_enqueue_scripts', [$this, 'zyncops_enqueue_styles']);
        add_action('wp_enqueue_scripts', [$this, 'zyncops_enqueue_styles']);


        add_action('admin_menu', [$this, 'add_plugin_menu']);

        // Register custom schedules
        add_filter('cron_schedules', [$this, 'add_custom_schedules']);

        // Schedule events
        add_action('init', [$this, 'schedule_events']);

        // Define event callbacks
        add_action('zyncops_daily_event', [$this, 'check_zyncops_licence']);
        // add_action('zyncops_daily_event', [$this, 'auto_update_order_status']);
        // add_action('zyncops_hourly_event', [$this, 'auto_update_order_status']);


        // Optional: Deactivation hook
        register_deactivation_hook(__FILE__, [$this, 'clear_scheduled_events']);



        $menu_settings = new MenuSettings(); // Fixed typo
        $menu_settings->addSettingsPage();

        $distribution = new OrderDistMenu();
        $distribution->init_action();

        $sale_report = new SaleReport();
        $sale_report->init_action();

        $restriction = new OrderRestrictionMenu();
        $restriction->init_action();

        // add_action('admin_menu', [$this, 'add_wc_cart_abandoned_submenu']);
        if ($is_enabled == 'no' || $is_licence_valid == 'no') {
            return;
        }

        add_action('init', function () {
            if (class_exists('WooCommerce')) {
                remove_all_filters('woocommerce_order_data_store_cpt_get_orders_query');
                // $this->auto_update_order_status();

                $cart_menu = new CartAbandonedMenu();
                $cart_menu->init_action();
                // trcak order hourly and update order states
                add_action('zyncops_hourly_event', [$this, 'auto_update_order_status']);

                $order_column = new ZyncOpsCourierColumn();
                $order_column->addColumn();

                $order_limit = new OrderLimit();
                $order_limit->init_action();

                $order_flow = new OrderFlowTracking();
                $order_flow->init_action();

                $cart_abandoned = new CartAbandoned();
                $cart_abandoned->init_action();

                $distribution_clmn = new OrderDistribution();
                $distribution_clmn->init_action();

                $fraud = new FraudCheck();
                $fraud->init_action();

                $tracking = new OrderTracking();
                $tracking->init_action();
            }
        });



    }

    public function add_plugin_menu()
    {
        // Main Menu: Courier Settings
        add_menu_page(
            'ZyncOps Settings',          // Page title
            'ZyncOps',          // Menu title
            'manage_options',            // Capability
            'zyncops-settings',          // Menu slug
            [$this, 'settings_page'],   // Callback
            'dashicons-admin-generic',   // Icon (optional)
            56                            // Position (optional)
        );

        // Submenu: Redx Credentials
        add_submenu_page(
            'zyncops-settings',            // Parent slug
            'Courier Configaration',            // Page title
            'Courier Configaration',            // Menu title
            'manage_options',              // Capability
            'zyncops-courier-configaration',       // Submenu slug
            [$this, 'courier_configaration_page'] // Callback
        );

        // Submenu: Redx Credentials
        add_submenu_page(
            'zyncops-settings',            // Parent slug
            'Redx Credentials',            // Page title
            'Redx Credentials',            // Menu title
            'manage_options',              // Capability
            'zyncops-settings-redx',       // Submenu slug
            [$this, 'redx_credentials_page'] // Callback
        );

        // Submenu: Steadfast Credentials
        add_submenu_page(
            'zyncops-settings',
            'Steadfast Credentials',
            'Steadfast Credentials',
            'manage_options',
            'zyncops-settings-steadfast',
            [$this, 'steadfast_credentials_page']
        );

        // Submenu: Pathao Credentials
        add_submenu_page(
            'zyncops-settings',
            'Pathao Credentials',
            'Pathao Credentials',
            'manage_options',
            'zyncops-settings-pathao',
            [$this, 'pathao_credentials_page']
        );

        // Submenu: Cart Abandoned Settings
        add_submenu_page(
            'zyncops-settings',                     // Parent slug
            'Cart Abandoned Settings',              // Page title
            'Cart Abandoned',                       // Menu title
            'manage_options',                       // Capability
            'zyncops-settings-abandoned-cart',      // Menu slug
            [$this, 'cart_abandoned_settings_page'] // Callback
        );

        // Submenu: order flow tracking
        add_submenu_page(
            'zyncops-settings',                     // Parent slug
            'Order Flow Settings',              // Page title
            'Order Flow Tracking',                       // Menu title
            'manage_options',                       // Capability
            'zyncops-settings-order-flow',      // Menu slug
            [$this, 'order_flow_settings_page'] // Callback
        );
    }

    public function settings_page()
    {
        ?>
        <div class="wrap">
            <h1>ZyncOps Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('zyncops_settings_group');
                do_settings_sections('zyncops-settings');
                submit_button('Save Settings');
                ?>
            </form>
        </div>
        <?php
    }

    public function redx_credentials_page()
    {
        ?>
        <div class="wrap">
            <h1>Redx Credentials</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('redx_credentials_group');
                do_settings_sections('zyncops-settings-redx');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function courier_configaration_page()
    {
        ?>
        <div class="wrap">
            <h1>Redx Credentials</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('zyncops_courier_conf_group');
                do_settings_sections('zyncops-courier-configaration');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function steadfast_credentials_page()
    {
        ?>
        <div class="wrap">
            <h1>Steadfast Credentials</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('steadfast_credentials_group');
                do_settings_sections('zyncops-settings-steadfast');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function pathao_credentials_page()
    {
        ?>
        <div class="wrap">
            <h1>Pathao Credentials</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('pathao_credentials_group');
                do_settings_sections('zyncops-settings-pathao');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }


    public function cart_abandoned_settings_page()
    {
        ?>
        <div class="wrap">
            <h1>Cart Abandoned Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('cart_abandoned_group');
                do_settings_sections('zyncops-settings-abandoned-cart');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function order_flow_settings_page()
    {
        ?>
        <div class="wrap">
            <h1>Order Flow Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('zyncops_order_flow_group');
                do_settings_sections('zyncops-settings-order-flow');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function zyncops_enqueue_styles()
    {
        $style_url = plugin_dir_url(__FILE__) . 'assets/css/zyncops-style.css';
        $style_version = '1.0';

        // Enqueue for admin area
        if (is_admin()) {
            wp_enqueue_style('zyncops-admin-style', $style_url, [], $style_version);
        }

        // Enqueue for frontend
        else {
            wp_enqueue_style('zyncops-public-style', $style_url, [], $style_version);
        }
    }

    public function add_custom_schedules($schedules)
    {
        $schedules['every_hour'] = [
            'interval' => 3600,
            'display' => __('Every Hour')
        ];

        $schedules['every_day'] = [
            'interval' => 86400,
            'display' => __('Every Day')
        ];

        return $schedules;
    }

    public function schedule_events()
    {
        if (!wp_next_scheduled('zyncops_hourly_event')) {
            wp_schedule_event(time(), 'every_hour', 'zyncops_hourly_event');
        }

        if (!wp_next_scheduled('zyncops_daily_event')) {
            wp_schedule_event(time(), 'every_day', 'zyncops_daily_event');
        }
    }

    public function auto_update_order_status()
    {
        if (defined('DOING_CRON') && DOING_CRON) {
            $admin_user = get_users([
                'role' => 'administrator',
                'number' => 1,
                'orderby' => 'ID',
                'order' => 'ASC',
            ]);

            if (!empty($admin_user)) {
                wp_set_current_user($admin_user[0]->ID);
            }
        }




        $orders = wc_get_orders([
            'status' => ['processing', 'on-hold', 'pending'],
            'limit' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);



        foreach ($orders as $order) {


            if (!$order instanceof WC_Order) {
                continue; // Skip if somehow not a WC_Order
            }

            $order_id = $order->get_id();
            $tracking_id = get_post_meta($order_id, 'zyncops_tracking_id', true);
            $platform = get_post_meta($order_id, 'courier_tracking_platform', true);

            if (!$tracking_id || !$platform) {
                continue;
            }

            $tracking = new OrderTracking();
            $response = $tracking->track_parcel($order_id);

            if (is_wp_error($response))
                continue;

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if (isset($data['status']) && is_string($data['status'])) {
                $status = $data['status'];

                if (strtolower($status) === 'completed') {
                    $order->update_status('completed', 'Auto-updated: Parcel marked as completed.');
                } elseif (strtolower($status) === 'cancelled') {
                    $order->update_status('cancelled', 'Auto-updated: Parcel was cancelled.');
                }

                // Optional: add latest tracking note
                if (isset($data['tracking']) && is_array($data['tracking']) && !empty($data['tracking'])) {
                    $last_tracking = end($data['tracking']);
                    $desc = $last_tracking['desc'] ?? '';
                    $order->add_order_note('Tracking update: ' . $desc);
                }

            }

            if (!get_post_meta($order_id, 'zyncops_tracking_id', true)) {
                update_post_meta($order_id, 'zyncops_tracking_id', $tracking_id);
            }
        }
    }

    public function check_zyncops_licence()
    {
        $licence_key = get_option('zyncops_licence_key', '');

        if (empty($licence_key)) {
            update_option('zyncops_licence_key_valid', 'no');
            return;
        }

        $parsed = parse_url(site_url());
        $domain = $parsed['host'];

        $payload = [
            'license_key' => $licence_key,
            'domain' => $domain,
        ];

        $response = wp_remote_post(BASE_URL . 'verify-license/', [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($payload),
            'timeout' => 20,
        ]);

        if (!is_wp_error($response)) {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if (isset($data['success']) && $data['success'] && $data['valid']) {
                update_option('zyncops_licence_key_valid', 'yes');
            } else {
                update_option('zyncops_licence_key_valid', 'no');
            }
        } else {
            update_option('zyncops_licence_key_valid', 'no');
        }
    }

    public function clear_scheduled_events()
    {
        wp_clear_scheduled_hook('zyncops_hourly_event');
        wp_clear_scheduled_hook('zyncops_daily_event');
    }



}

add_action('plugins_loaded', function () {
    new ZyncOps();
});

/**
 * WooCommerce HPOS support
 */
add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
    }
});


function zyncops_create_abandoned_cart_table()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'zyncops_abandoned_cart';

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_identifier VARCHAR(100) NOT NULL,
        items LONGTEXT NOT NULL,
        email VARCHAR(191),
        name VARCHAR(191),
        phone VARCHAR(191),
        address LONGTEXT,
        completion_ratio INT DEFAULT 0,
        action ENUM('abandoned', 'converted') DEFAULT 'abandoned',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX (user_identifier)
    ) $charset_collate;";

    dbDelta($sql);
}

function create_courier_data_table()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'zyncops_courier_data';

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        phone VARCHAR(100) NOT NULL,
        total INT DEFAULT 0,
        success INT DEFAULT 0,
        cancel INT DEFAULT 0,
        cancel_ratio INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX (phone)
    ) $charset_collate;";

    dbDelta($sql);
}

register_activation_hook(__FILE__, 'zyncops_create_abandoned_cart_table');
register_activation_hook(__FILE__, 'create_courier_data_table');
